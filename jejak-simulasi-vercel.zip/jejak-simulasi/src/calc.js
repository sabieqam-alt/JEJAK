/*
 * calc.js — INTI PERHITUNGAN. Fungsi murni: tidak menyentuh DOM, tidak membaca jam,
 * tidak menyimpan apa pun. Karena itu bisa diuji di Node (lihat tests/run.js).
 *
 * Rumus (Modul 4):
 *   listrik (T2) : kWh = Rp ÷ tarif ;             kgCO2e = kWh × faktor jaringan
 *   barang  (T1) : USD = Rp ÷ kurs ;              kgCO2e = USD × faktor per USD
 *   barang  (T2/T3, naik tangga) : kgCO2e = kuantitas × faktor per satuan
 *
 * "m" (pengali) dipakai untuk sensitivitas. Nilai bawaan 1 = tanpa perubahan:
 *   c3 faktor barang T1 | tarif | jaringan | kurs | t2 | t3
 */
(function (root) {
  'use strict';
  var J = (root.JEJAK = root.JEJAK || {});
  var MINUS = '−';

  /* ================= Format angka gaya Indonesia ================= */

  function kelompok(digits) { return digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }

  /** 1163.03, 1 → "1.163,0"   |   −11.2, 1 → "−11,2" */
  function fmtNum(n, d) {
    if (n === null || n === undefined || !isFinite(n)) return '–';
    d = d === undefined ? 0 : d;
    var teks = Math.abs(n).toFixed(d);
    var neg = n < 0 && Number(teks) !== 0;
    var bagian = teks.split('.');
    return (neg ? MINUS : '') + kelompok(bagian[0]) + (bagian[1] ? ',' + bagian[1] : '');
  }

  /** Seperti fmtNum tetapi membuang nol di belakang koma: 10.5 → "10,5", 25 → "25". */
  function fmtRingkas(n, maks) {
    var s = fmtNum(n, maks === undefined ? 2 : maks);
    return s.indexOf(',') >= 0 ? s.replace(/0+$/, '').replace(/,$/, '') : s;
  }

  function fmtRp(n) {
    if (n === null || n === undefined || !isFinite(n)) return '–';
    return (n < 0 ? MINUS : '') + 'Rp' + fmtNum(Math.abs(n), 0);
  }

  /** 10500000 → "Rp10,5 juta" */
  function fmtJuta(n) { return 'Rp' + fmtRingkas(n / 1e6, 2) + ' juta'; }

  /** pecahan 0.777 → "77,7%" */
  function fmtPct(x, d) { return fmtNum(x * 100, d === undefined ? 1 : d) + '%'; }

  /** pecahan → "+22,3%" atau "−11,2%" */
  function fmtTanda(x, d) {
    var teks = fmtNum(Math.abs(x) * 100, d === undefined ? 1 : d);
    var nol = Number(Math.abs(x * 100).toFixed(d === undefined ? 1 : d)) === 0;
    return (nol ? '' : (x < 0 ? MINUS : '+')) + teks + '%';
  }

  /**
   * Membaca angka yang diketik orang Indonesia.
   *   "1.500.000" → 1500000   "1.444,70" → 1444.7   "1444.7" → 1444.7   "0,87" → 0.87   "Rp 6.000.000" → 6000000
   * Titik = ribuan jika polanya 1.234 / 12.345.678; selain itu dianggap desimal gaya Inggris.
   * Mengembalikan NaN jika tidak bisa dibaca.
   */
  function parseNum(masuk) {
    if (typeof masuk === 'number') return isFinite(masuk) ? masuk : NaN;
    var s = String(masuk == null ? '' : masuk).replace(/rp/ig, '').replace(/[\s _]/g, '').replace(/−/g, '-');
    if (!/^-?[\d.,]+$/.test(s)) return NaN;
    var neg = s.charAt(0) === '-';
    if (neg) s = s.slice(1);
    var koma = s.split(',').length - 1, titik = s.split('.').length - 1, hasil;
    if (koma > 1) return NaN;
    if (koma === 1) {
      var ab = s.split(',');
      if (!/^\d+$/.test(ab[1])) return NaN;
      if (titik > 0 && !/^\d{1,3}(\.\d{3})+$/.test(ab[0])) return NaN;
      hasil = ab[0].replace(/\./g, '') + '.' + ab[1];
    } else if (titik === 0) {
      hasil = s;
    } else if (/^[1-9]\d{0,2}(\.\d{3})+$/.test(s)) {
      hasil = s.replace(/\./g, '');
    } else if (titik === 1) {
      hasil = s;
    } else {
      return NaN;
    }
    var v = parseFloat(hasil);
    return isFinite(v) ? (neg ? -v : v) : NaN;
  }

  /* ================= Perhitungan emisi ================= */

  function pengaliBawaan() { return { c3: 1, tarif: 1, jaringan: 1, kurs: 1, t2: 1, t3: 1 }; }

  /** Hitung satu pos. Mengembalikan juga angka antara agar UI bisa menampilkan langkahnya. */
  function hitungPos(p, param, m) {
    m = Object.assign(pengaliBawaan(), m || {});
    var r = { id: p.id, nama: p.nama, kat: p.kat, tier: p.tier, rupiah: p.rupiah, slot: p.slot };
    if (p.kat === 'listrik') {
      r.metode = 'kwh';
      r.tarif = param.tarif * m.tarif;
      r.faktor = param.jaringan * m.jaringan;
      r.kwh = p.rupiah / r.tarif;
      r.kg = r.kwh * r.faktor;
    } else if (p.tier === 'T1') {
      r.metode = 'usd';
      r.kurs = param.kurs * m.kurs;
      r.faktor = p.faktorUSD * m.c3;
      r.usd = p.rupiah / r.kurs;
      r.kg = r.usd * r.faktor;
    } else {
      r.metode = 'qty';
      r.unit = p.unit || 'kg';
      r.qty = p.qty;
      r.faktor = p.fq * (p.tier === 'T3' ? m.t3 : m.t2);
      r.kg = r.qty * r.faktor;
    }
    return r;
  }

  /** inp = { penjualan, belanjaTotal, param, pos[] } */
  function hitungSemua(inp, m) {
    var rows = inp.pos.map(function (p) { return hitungPos(p, inp.param, m); });
    var totalKg = rows.reduce(function (a, r) { return a + r.kg; }, 0);
    var terekam = inp.pos.reduce(function (a, p) { return a + p.rupiah; }, 0);
    var belanjaTotal = Math.max(inp.belanjaTotal, terekam);
    rows.forEach(function (r) { r.porsi = totalKg > 0 ? r.kg / totalKg : 0; });
    return {
      rows: rows,
      totalKg: totalKg,
      tahunTon: totalKg * 12 / 1000,
      intensitas: inp.penjualan > 0 ? totalKg / (inp.penjualan / 1e6) : null,
      terekam: terekam,
      belanjaTotal: belanjaTotal,
      tunai: belanjaTotal - terekam,
      cakupan: belanjaTotal > 0 ? terekam / belanjaTotal : 0,
      disesuaikan: inp.belanjaTotal < terekam
    };
  }

  /**
   * Sensitivitas satu-per-satu dan gabungan (Modul 5).
   * Arah rendah/tinggi dipilih supaya "rendah" benar-benar menurunkan total:
   * tarif naik → kWh turun; kurs naik → USD turun.
   */
  function sensitivitas(inp, band) {
    var dasar = hitungSemua(inp).totalKg;
    var ada = {
      listrik: inp.pos.some(function (p) { return p.kat === 'listrik'; }),
      t1: inp.pos.some(function (p) { return p.kat === 'bahan' && p.tier === 'T1'; }),
      t2: inp.pos.some(function (p) { return p.kat === 'bahan' && p.tier === 'T2'; }),
      t3: inp.pos.some(function (p) { return p.kat === 'bahan' && p.tier === 'T3'; })
    };
    var f = [];
    if (ada.t1) f.push({ kunci: 'c3', label: 'Faktor emisi Cakupan 3', ket: 'barang T1, ×' + fmtRingkas(band.c3[0]) + ' hingga ×' + fmtRingkas(band.c3[1]), lo: { c3: band.c3[0] }, hi: { c3: band.c3[1] } });
    if (ada.listrik) f.push({ kunci: 'tarif', label: 'Tarif listrik', ket: '±' + band.tarif + '%, tarif naik berarti kWh turun', lo: { tarif: 1 + band.tarif / 100 }, hi: { tarif: 1 - band.tarif / 100 } });
    if (ada.listrik) f.push({ kunci: 'jaringan', label: 'Faktor emisi jaringan', ket: 'listrik Jawa–Madura–Bali, ±' + band.jaringan + '%', lo: { jaringan: 1 - band.jaringan / 100 }, hi: { jaringan: 1 + band.jaringan / 100 } });
    if (ada.t1) f.push({ kunci: 'kurs', label: 'Kurs', ket: '±' + band.kurs + '%, kurs naik berarti USD turun', lo: { kurs: 1 + band.kurs / 100 }, hi: { kurs: 1 - band.kurs / 100 } });
    if (ada.t2) f.push({ kunci: 't2', label: 'Faktor per satuan (T2)', ket: 'ilustrasi, ×' + fmtRingkas(band.t2[0]) + ' hingga ×' + fmtRingkas(band.t2[1]), lo: { t2: band.t2[0] }, hi: { t2: band.t2[1] } });
    if (ada.t3) f.push({ kunci: 't3', label: 'Faktor pemasok (T3)', ket: 'ilustrasi, ×' + fmtRingkas(band.t3[0]) + ' hingga ×' + fmtRingkas(band.t3[1]), lo: { t3: band.t3[0] }, hi: { t3: band.t3[1] } });

    var baris = f.map(function (x) {
      var lo = hitungSemua(inp, x.lo).totalKg, hi = hitungSemua(inp, x.hi).totalKg;
      return Object.assign({}, x, { lo: lo, hi: hi, loPct: dasar > 0 ? lo / dasar - 1 : 0, hiPct: dasar > 0 ? hi / dasar - 1 : 0 });
    });
    var mLo = Object.assign.apply(null, [{}].concat(f.map(function (x) { return x.lo; })));
    var mHi = Object.assign.apply(null, [{}].concat(f.map(function (x) { return x.hi; })));
    var gLo = hitungSemua(inp, mLo).totalKg, gHi = hitungSemua(inp, mHi).totalKg;
    baris.sort(function (a, b) { return (b.hi - b.lo) - (a.hi - a.lo); });
    return {
      dasar: dasar,
      faktor: baris,
      gabungan: { lo: gLo, hi: gHi, loPct: dasar > 0 ? gLo / dasar - 1 : 0, hiPct: dasar > 0 ? gHi / dasar - 1 : 0 }
    };
  }

  /**
   * Pemeriksa independen: jalur hitung terpisah (rasio langsung, tanpa angka antara).
   * Hasilnya harus sama dengan hitungSemua. Jika tidak, ada yang salah di salah satu jalur.
   */
  function hitungUlangIndependen(inp) {
    var rows = [], total = 0;
    inp.pos.forEach(function (p) {
      var kg;
      if (p.kat === 'listrik') kg = (p.rupiah * inp.param.jaringan) / inp.param.tarif;
      else if (p.tier === 'T1') kg = (p.rupiah * p.faktorUSD) / inp.param.kurs;
      else kg = p.qty * p.fq;
      rows.push({ id: p.id, kg: kg });
      total += kg;
    });
    return { rows: rows, total: total };
  }

  /** Laba rugi minimal dari akun sederhana (Langkah 3). */
  function labaRugi(inp) {
    var jumlah = function (kat) {
      return inp.pos.filter(function (p) { return p.kat === kat; }).reduce(function (a, p) { return a + p.rupiah; }, 0);
    };
    var bahan = jumlah('bahan'), listrik = jumlah('listrik'), terekam = bahan + listrik;
    var totalBeban = Math.max(inp.belanjaTotal, terekam);
    var laba = inp.penjualan - totalBeban;
    return {
      penjualan: inp.penjualan, bahan: bahan, listrik: listrik, tunai: totalBeban - terekam,
      totalBeban: totalBeban, laba: laba, marjin: inp.penjualan > 0 ? laba / inp.penjualan : null
    };
  }

  J.calc = {
    fmtNum: fmtNum, fmtRingkas: fmtRingkas, fmtRp: fmtRp, fmtJuta: fmtJuta, fmtPct: fmtPct, fmtTanda: fmtTanda,
    parseNum: parseNum,
    pengaliBawaan: pengaliBawaan, hitungPos: hitungPos, hitungSemua: hitungSemua,
    sensitivitas: sensitivitas, hitungUlangIndependen: hitungUlangIndependen, labaRugi: labaRugi
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = J.calc;
})(typeof window !== 'undefined' ? window : globalThis);
