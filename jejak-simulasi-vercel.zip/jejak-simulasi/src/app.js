/*
 * app.js — perangkai. Membaca state, menggambar langkah aktif, dan menangani SEMUA kejadian
 * lewat delegasi di satu tempat. Tidak ada rumus hitung di sini (lihat calc.js).
 *
 * Penanda di HTML yang ditulis file di src/steps/:
 *   data-act="nama"            klik tombol            → fungsi di KLIK
 *   data-in="angka|pos|usaha"  sedang mengetik        → ubah state diam-diam (tanpa log), tampilan langsung ikut
 *   data-ch="nama"             selesai mengubah       → fungsi di UBAH (di sinilah log ditulis)
 *   data-form="nama"           formulir dikirim       → fungsi di KIRIM
 *
 * Menambah tombol baru: tulis <button data-act="halo"> di langkah, lalu tambahkan  halo: function (el) {...}  di KLIK.
 * `ui` di bawah adalah keadaan tampilan sementara (galat, panel terbuka); tidak disimpan di localStorage.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui, S = J.store, H = J.hash, L = J.langkah;
  var doc = root.document;
  var F = C.fmtNum, KG = U.KG;

  function uiBaru() {
    return {
      galat: {},                       // pesan galat per kolom, kunci = data-key
      open: {},                        // <details data-key> yang sedang terbuka
      form: { kat: 'bahan', faktorPilih: D.faktorPilihan[0].id },   // pilihan formulir tambah pos
      formTangga: { tier: 'T2', latihan: false },                   // pilihan formulir naik tangga
      tangga: null,                    // id pos yang formulir naik tangganya terbuka
      diperiksa: null,                 // waktu terakhir rantai log diperiksa
      rusakPilih: 1,                   // entri log yang dipilih untuk dicoba dipalsukan
      sebelum: {},                     // nilai kolom saat mulai diedit (untuk teks log "dari ... menjadi ...")
      konfirmReset: false
    };
  }
  var ui = uiBaru();
  var akar = {}, langkahTampil = null;

  /* ================= Bantuan kecil ================= */

  function umumkan(teks) {
    akar.siaran.textContent = '';
    root.setTimeout(function () { akar.siaran.textContent = teks; }, 30);
  }

  function namaIzin(ak) {
    return ak.kurang.map(function (k) { return D.izin.filter(function (i) { return i.id === k; })[0].pendek; }).join(ak.salahSatu ? ' atau ' : ' dan ');
  }

  function bacaHash() {
    var m = /^#\/([1-7])$/.exec(root.location.hash);
    return m ? parseInt(m[1], 10) : null;
  }

  function pesanGalat(teks) {
    return String(teks).trim() === '' ? 'Isi angka lebih dari 0.' : 'Tulis angka lebih dari 0, misalnya 1.500.000 atau 0,87.';
  }

  /** Nilai asli di state untuk sebuah kolom (bukan teks yang tampil). */
  function nilaiState(el) {
    var s = S.ambil(), jenis = el.dataset['in'];
    if (jenis === 'usaha') return s.usaha;
    if (jenis === 'angka') {
      var k = el.dataset.kunci;
      return k === 'penjualan' ? s.penjualan : k === 'belanjaTotal' ? s.belanjaTotal : s.param[k];
    }
    if (jenis === 'pos') { var p = S.cariPos(s, el.dataset.id); return p ? p[el.dataset.bidang] : undefined; }
  }

  /* ================= Bagian layar di luar langkah: rel, pita, tombol atas ================= */

  function pitaHtml(c) {
    var s = c.s, ak = S.akses(s, 4), t = c.t;
    var h = '<section class="pita" aria-labelledby="pita-judul"><h2 id="pita-judul">Pita hasil</h2>';
    if (!ak.ok) return h + '<p class="pita-kosong">Belum ada angka. Estimasi muncul setelah izin ' + namaIzin(ak) + ' diberikan.</p></section>';
    var hh = t.h, g = t.sens.gabungan, v = H.verifikasi(s.log), kode = H.segelPendek(S.segelKartu(s, t)), d = hh.totalKg - S.dasar().totalKg;
    h += '<div class="tumpuk kecil" aria-hidden="true">' + hh.rows.map(function (r) {
      return '<span style="--w:' + U.warna(r.slot) + ';flex:' + Math.max(r.kg, 0.0001) + ' 1 0"></span>';
    }).join('') + '</div><dl>' +
      '<div><dt>Total</dt><dd><b>' + F(hh.totalKg, 1) + '</b> ' + KG + '</dd></div>' +
      '<div class="sek"><dt>Rentang</dt><dd>' + F(g.lo, 0) + ' sampai ' + F(g.hi, 0) + '</dd></div>' +
      '<div class="sek"><dt>Setahun</dt><dd>' + F(hh.tahunTon, 2) + ' t' + U.CO2E + '</dd></div>' +
      '<div class="sek"><dt>Cakupan</dt><dd>' + C.fmtPct(hh.cakupan, 0) + '</dd></div>' +
      (Math.abs(d) >= 0.05 ? '<div class="selisih"><dt>Dari kasus awal</dt><dd>' + (d > 0 ? '+' : '') + F(d, 1) + '</dd></div>' : '') +
      '<div class="segel' + (v.ok ? '' : ' putus') + '"><dt>Segel</dt><dd>' + kode + (v.ok ? '' : ' (putus)') + '</dd></div></dl></section>';
    return h;
  }

  function relHtml(c) {
    var s = c.s, h = '<nav aria-label="Langkah simulasi">', fase = null, buka = false;
    for (var n = 1; n <= S.JUMLAH_LANGKAH; n++) {
      var l = L[n], ak = S.akses(s, n);
      if (l.fase !== fase) {
        if (buka) h += '</ol></div>';
        fase = l.fase; buka = true;
        h += '<div class="grup"><p class="fase">' + fase + '</p><ol start="' + n + '">';
      }
      var kelas = 'lk' + (n === s.langkah ? ' aktif' : '') + (!ak.ok ? ' terkunci' : '') + (n !== s.langkah && s.dilihat.indexOf(n) >= 0 ? ' dilihat' : '');
      h += '<li><a class="' + kelas + '" href="#/' + n + '"' + (n === s.langkah ? ' aria-current="step"' : '') + (!ak.ok ? ' title="Butuh izin: ' + namaIzin(ak) + '"' : '') + '>' +
        '<span class="nomor">' + n + '</span><span class="nama">' + l.judul + '</span>' +
        (!ak.ok ? '<span class="lk-kunci">' + U.ikon('kunci', 14) + '<span class="sr">, terkunci</span></span>' : '') + '</a></li>';
    }
    if (buka) h += '</ol></div>';
    return h + '</nav>' + pitaHtml(c);
  }

  function aksiAtas() {
    if (ui.konfirmReset) {
      return '<span class="konfirm" role="alert">Hapus semua perubahan dan mulai dari awal?</span>' +
        '<button type="button" class="tombol utama" data-act="resetYa">Ya, mulai ulang</button>' +
        '<button type="button" class="tombol sekunder" data-act="resetBatal">Batal</button>';
    }
    return '<button type="button" class="tombol sekunder" data-act="reset">' + U.ikon('ulang', 16) + 'Mulai ulang</button>';
  }

  /* ================= Menggambar ================= */

  function render() {
    var s = S.ambil(), n = s.langkah;
    var ganti = langkahTampil !== n;
    if (ganti) { ui.galat = {}; ui.tangga = null; ui.konfirmReset = false; akar.isi.textContent = ''; }
    try {
      var c = { s: s, t: S.turunan(s), ui: ui, ak: S.akses(s, n) };
      U.morph(akar.isi, L[n].render(c) + U.nav(c, n));
      U.morph(akar.rel, relHtml(c));
      U.morph(akar.aksi, aksiAtas());
      doc.title = 'Langkah ' + n + ': ' + L[n].judul + ' | JEJAK simulasi';
    } catch (e) {
      if (root.console) root.console.error(e);
      akar.isi.innerHTML = '<div class="catatan awas"><span>Tampilan gagal digambar. Data yang tersimpan mungkin rusak. Tombol Mulai ulang di kanan atas menghapusnya.</span></div>';
      return;
    }
    if (ganti) {
      var awal = langkahTampil === null;
      langkahTampil = n;
      root.scrollTo(0, 0);
      if (!awal) {
        var h1 = doc.getElementById('judul-langkah');
        if (h1) h1.focus({ preventScroll: true });
        umumkan('Langkah ' + n + ': ' + L[n].judul);
      }
    }
  }

  /* ================= Klik tombol ================= */

  function slug(t) { return String(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'usaha'; }

  function unduhJson() {
    var s = S.ambil(), t = S.turunan(s), isi = S.kartuIsi(s, t), segel = H.segel(isi, S.kepalaLog(s));
    var paket = { jenis: 'kartu-jejak-hijau-simulasi', segel: H.segelPendek(segel), sidikJari: segel, kartu: isi, catatan: D.disclaimer };
    var blob = new root.Blob([JSON.stringify(paket, null, 2)], { type: 'application/json' });
    var url = root.URL.createObjectURL(blob), a = doc.createElement('a');
    a.href = url; a.download = 'kartu-jejak-hijau-' + slug(s.usaha) + '.json';
    doc.body.appendChild(a); a.click(); a.parentNode.removeChild(a);
    root.setTimeout(function () { root.URL.revokeObjectURL(url); }, 1000);
    umumkan('Berkas JSON diunduh.');
  }

  var KLIK = {
    lompat: function () { akar.isi.focus(); },

    izin: function (el) { S.act('izin', { kunci: el.dataset.kunci, nilai: el.dataset.nilai !== '0' }); },
    izinSemua: function () { S.act('izinSemua'); umumkan('Semua izin diberikan.'); },

    hapusPos: function (el) {
      var p = S.cariPos(S.ambil(), el.dataset.id);
      S.act('hapusPos', { id: el.dataset.id });
      if (p) umumkan('Pos ' + p.nama + ' dihapus.');
    },

    bukaTangga: function (el) {
      ui.tangga = el.dataset.id; ui.formTangga = { tier: 'T2', latihan: false }; ui.galat.naikTangga = null;
      render();
      var q = doc.getElementById('nt-qty'); if (q) q.focus();
    },
    tutupTangga: function () { ui.tangga = null; ui.galat.naikTangga = null; render(); },
    turunTangga: function (el) { S.act('turunTangga', { id: el.dataset.id }); umumkan('Pos dikembalikan ke T1.'); },
    isiLatihan: function (el) {
      var f = el.closest('form'); if (!f) return;
      f.elements.qty.value = C.fmtRingkas(D.latihan.qty, 2);
      f.elements.unit.value = D.latihan.unit;
      f.elements.fq.value = C.fmtRingkas(D.latihan.fq, 4);
      f.elements.sumber.value = D.latihan.sumber;
      ui.formTangga.latihan = true; ui.galat.naikTangga = null;
      render();
    },
    latihanListrik: function () {
      var p = S.cariPos(S.ambil(), 'listrik'); if (!p) return;
      var awal = D.pos.filter(function (x) { return x.id === 'listrik'; })[0].rupiah;
      S.act('pos', { id: 'listrik', bidang: 'rupiah', nilai: p.rupiah === D.skenarioListrik ? awal : D.skenarioListrik });
    },

    periksa: function () {
      ui.diperiksa = new Date().toISOString(); render();
      var v = H.verifikasi(S.ambil().log);
      umumkan(v.ok ? 'Rantai utuh, ' + v.jumlah + ' entri diperiksa.' : 'Rantai putus di entri ' + v.di + '.');
    },
    rusak: function () { S.act('rusak', { i: ui.rusakPilih }); umumkan('Entri ' + ui.rusakPilih + ' diubah diam-diam. Periksa rantai untuk melihat hasilnya.'); },
    pulihkan: function () { S.act('pulihkan'); umumkan('Entri dipulihkan.'); },

    cetak: function () { root.print(); },
    unduh: unduhJson,
    cabutBagi: function (el) { S.act('bagi', { id: el.dataset.id, aktif: false }); },

    reset: function () { ui.konfirmReset = true; render(); },
    resetBatal: function () { ui.konfirmReset = false; render(); },
    resetYa: function () {
      ui = uiBaru(); langkahTampil = null; J.app.ui = ui;
      S.act('reset');
      root.location.hash = '#/1';
      umumkan('Simulasi dimulai ulang dari kasus awal.');
    }
  };

  /* ================= Mengetik dan mengubah kolom ================= */

  var PENANGAN = {
    angka: function (el, nilai, opsi) { S.act('angka', Object.assign({ kunci: el.dataset.kunci, nilai: nilai }, opsi)); },
    pos: function (el, nilai, opsi) { S.act('pos', Object.assign({ id: el.dataset.id, bidang: el.dataset.bidang, nilai: nilai }, opsi)); }
  };

  /** Saat mengetik: state ikut berubah supaya semua angka hidup, tetapi log belum ditulis. */
  function saatInput(e) {
    var el = e.target, jenis = el.dataset && el.dataset['in'];
    if (!jenis) return;
    var kunci = el.dataset.key;
    if (jenis === 'usaha') { S.act('usaha', { nilai: el.value, sunyi: true }); return; }
    var nilai = C.parseNum(el.value);
    if (!(nilai > 0)) { ui.galat[kunci] = pesanGalat(el.value); render(); return; }
    delete ui.galat[kunci];
    PENANGAN[jenis](el, nilai, { sunyi: true });
  }

  /** Saat selesai (pindah kolom atau Enter): catat ke log dan rapikan tampilan angka. */
  function saatUbah(e) {
    var el = e.target, ch = el.dataset && el.dataset.ch;
    if (!ch) return;
    var kunci = el.dataset.key;
    switch (ch) {
      case 'usaha':
        S.act('usaha', { nilai: el.value, sebelum: ui.sebelum[kunci] });
        ui.sebelum[kunci] = el.value;
        break;
      case 'angka':
      case 'pos': {
        var nilai = C.parseNum(el.value);
        if (!(nilai > 0)) { if (!ui.galat[kunci]) { ui.galat[kunci] = pesanGalat(el.value); render(); } return; }
        delete ui.galat[kunci];
        PENANGAN[ch](el, nilai, { sebelum: ui.sebelum[kunci] });
        ui.sebelum[kunci] = nilai;
        el.value = el.getAttribute('value');
        break;
      }
      case 'izin': S.act('izin', { kunci: el.dataset.kunci, nilai: el.checked }); break;
      case 'sampel': S.act('sampel', { id: el.dataset.id, nilai: el.checked }); break;
      case 'bagi': S.act('bagi', { id: el.dataset.id, aktif: el.checked }); break;
      case 'bagiBidang': S.act('bagiBidang', { id: el.dataset.id, bidang: el.dataset.bidang, nilai: el.checked }); break;
      case 'formPilih': ui.form[el.dataset.nama] = el.value; render(); break;
      case 'formTangga': ui.formTangga[el.dataset.nama] = el.value; render(); break;
      case 'pilihRusak': ui.rusakPilih = parseInt(el.value, 10) || 1; render(); break;
    }
  }

  /* ================= Formulir ================= */

  var KIRIM = {
    tambahPos: function (f) {
      var d = Object.assign({}, Object.fromEntries(new root.FormData(f)), { kat: ui.form.kat, faktorPilih: ui.form.faktorPilih });
      var cek = S.cekPosBaru(S.ambil(), d);
      if (!cek.ok) { ui.galat.tambahPos = cek.galat; render(); return; }
      ui.galat.tambahPos = null;
      S.act('tambahPos', d);
      f.reset();
      umumkan('Pos ' + cek.pos.nama + ' ditambahkan.');
      var n = f.elements.nama; if (n) n.focus();
    },
    naikTangga: function (f) {
      var d = Object.fromEntries(new root.FormData(f)), lat = D.latihan;
      var latihan = ui.formTangga.latihan && C.parseNum(d.qty) === lat.qty && C.parseNum(d.fq) === lat.fq &&
        String(d.unit).trim() === lat.unit && String(d.sumber).trim() === lat.sumber;
      var data = { id: f.dataset.id, tier: ui.formTangga.tier, qty: d.qty, unit: d.unit, fq: d.fq, sumber: d.sumber, latihan: latihan };
      var cek = S.cekNaikTangga(S.ambil(), data);
      if (!cek.ok) { ui.galat.naikTangga = cek.galat; render(); return; }
      ui.galat.naikTangga = null; ui.tangga = null;
      S.act('naikTangga', data);
      umumkan('Pos naik ke ' + cek.data.tier + ' dan estimasi dihitung ulang.');
    }
  };

  /* ================= Pasang penangan dan mulai ================= */

  function pasang() {
    doc.addEventListener('click', function (e) {
      var el = e.target.closest ? e.target.closest('[data-act]') : null;
      if (!el || el.disabled) return;
      var f = KLIK[el.dataset.act];
      if (!f) return;
      if (el.tagName === 'A') e.preventDefault();
      f(el, e);
    });
    doc.addEventListener('input', saatInput);
    doc.addEventListener('change', saatUbah);
    doc.addEventListener('focusin', function (e) {
      var el = e.target;
      if (el.dataset && el.dataset['in']) ui.sebelum[el.dataset.key] = nilaiState(el);
    });
    doc.addEventListener('toggle', function (e) {
      var el = e.target;
      if (el.tagName === 'DETAILS' && el.dataset.key) ui.open[el.dataset.key] = el.open;
    }, true);
    doc.addEventListener('submit', function (e) {
      var f = e.target.closest ? e.target.closest('[data-form]') : null;
      if (!f || !KIRIM[f.dataset.form]) return;
      e.preventDefault();
      KIRIM[f.dataset.form](f);
    });
    root.addEventListener('hashchange', function () {
      var n = bacaHash();
      if (n && n !== S.ambil().langkah) S.act('ke', { n: n });
    });
  }

  function mulai() {
    akar.isi = doc.getElementById('isi');
    akar.rel = doc.getElementById('rel');
    akar.aksi = doc.getElementById('aksi-atas');
    akar.siaran = doc.getElementById('siaran');
    akar.kaki = doc.getElementById('kaki');
    akar.kaki.innerHTML = '<p>' + D.disclaimer + '</p>';

    var s = S.mulai(), n = bacaHash();
    if (n && n !== s.langkah) S.act('ke', { n: n });
    else if (!n) root.history.replaceState(null, '', '#/' + s.langkah);
    S.langganan(render);
    pasang();
    render();
  }

  J.app = { ui: ui, render: render };
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', mulai); else mulai();
})(typeof window !== 'undefined' ? window : globalThis);
