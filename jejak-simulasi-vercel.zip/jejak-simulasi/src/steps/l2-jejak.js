/*
 * Langkah 2: Jejak transaksi (data dua arah: uang masuk dan uang keluar).
 * Angka yang diubah di sini mengalir ke semua langkah berikutnya.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui, S = J.store;

  function barisPos(c, p) {
    var kunci = 'pos:' + p.id + ':rupiah';
    var jenis = p.kat === 'listrik' ? 'Listrik' : 'Barang';
    var hapus = !S.bawaan(p.id)
      ? '<button type="button" class="ikon-tombol" data-act="hapusPos" data-id="' + U.esc(p.id) + '" aria-label="Hapus pos ' + U.esc(p.nama) + '">' + U.ikon('hapus', 16) + '</button>'
      : '<span></span>';
    return '<li class="pos" style="--w:' + U.warna(p.slot) + '">' +
      '<span class="warna" aria-hidden="true"></span>' +
      '<div class="nama"><b>' + U.esc(p.nama) + '</b><span>' + jenis + ', ' + p.cakupan + '</span></div>' +
      '<div class="label-t">' + U.tingkat(p.tier, p.latihan) + '</div>' +
      U.inputAngka({ kunci: kunci, masuk: 'pos', nilai: C.fmtNum(p.rupiah), label: 'Belanja ' + U.esc(p.nama) + ' per bulan', awalan: 'Rp', data: { id: p.id, bidang: 'rupiah' }, galat: c.ui.galat[kunci], kecil: true }) +
      hapus + '</li>';
  }

  function formTambah(c) {
    var f = c.ui.form, galat = c.ui.galat.tambahPos;
    var h = '<details class="tambah" data-key="tambahPos"' + (c.ui.open.tambahPos ? ' open' : '') + '><summary>Tambah pos belanja <span class="sisa">' + c.s.pos.length + ' dari ' + D.maksPos + ' pos</span></summary>';
    if (c.s.pos.length >= D.maksPos) return h + '<p class="catatan">Batas ' + D.maksPos + ' pos tercapai. Hapus pos tambahan untuk menambah yang lain.</p></details>';
    h += '<form data-form="tambahPos" novalidate>' +
      '<div class="isi lebar"><label for="tp-nama">Nama pos</label><span class="kolom"><input id="tp-nama" name="nama" type="text" maxlength="32" autocomplete="off"></span></div>' +
      '<fieldset class="pilih"><legend>Jenis belanja</legend>' +
      '<label><input type="radio" name="kat" value="bahan" data-ch="formPilih" data-nama="kat"' + (f.kat === 'bahan' ? ' checked' : '') + '> Barang, dihitung dari belanja (T1)</label>' +
      '<label><input type="radio" name="kat" value="listrik" data-ch="formPilih" data-nama="kat"' + (f.kat === 'listrik' ? ' checked' : '') + '> Listrik, dihitung dari kWh (T2)</label></fieldset>' +
      '<div class="isi"><label for="tp-rupiah">Belanja per bulan</label><span class="kolom"><span class="aw">Rp</span><input id="tp-rupiah" class="angka" name="rupiah" type="text" inputmode="decimal" autocomplete="off"></span></div>';
    if (f.kat === 'bahan') {
      h += '<div class="isi lebar"><label for="tp-faktor">Faktor emisi per USD belanja</label><span class="kolom"><select id="tp-faktor" name="faktorPilih" data-ch="formPilih" data-nama="faktorPilih">';
      D.faktorPilihan.forEach(function (x) {
        h += '<option value="' + x.id + '"' + (f.faktorPilih === x.id ? ' selected' : '') + '>' + x.label + ', ' + C.fmtRingkas(x.nilai, 3) + ' kgCO2e per USD (' + x.sumber + ')</option>';
      });
      h += '<option value="lain"' + (f.faktorPilih === 'lain' ? ' selected' : '') + '>Lainnya: isi faktor dan sumbernya sendiri</option></select></span></div>';
      if (f.faktorPilih === 'lain') {
        h += '<div class="isi"><label for="tp-fe">Faktor emisi</label><span class="kolom"><input id="tp-fe" class="angka" name="faktorUSD" type="text" inputmode="decimal" autocomplete="off"><span class="ak">kgCO<sub>2</sub>e per USD</span></span></div>' +
          '<div class="isi lebar"><label for="tp-sumber">Sumber faktor</label><span class="kolom"><input id="tp-sumber" name="sumber" type="text" maxlength="120" autocomplete="off"></span><span class="bantu">Wajib. Angka tanpa sumber tidak bisa diperiksa.</span></div>';
      }
    }
    h += '<div class="aksi-baris"><button type="submit" class="tombol utama">' + U.ikon('tambah', 16) + 'Tambah pos</button>' +
      (galat ? '<span class="galat" role="alert">' + U.esc(galat) + '</span>' : '') + '</div></form></details>';
    return h;
  }

  J.langkah[2] = {
    n: 2, fase: 'Penerapan', judul: 'Jejak transaksi',
    render: function (c) {
      var s = c.s, ui = c.ui, t = c.t, hh = t.h;
      var h = U.kepala(this, 'Data dua arah: penjualan dari laporan settlement QRIS, pembelian dari pembayaran keluar dan foto nota. Aplikasi hanya melihat yang terekam digital.');
      if (!c.ak.ok) return h + U.terkunci(c, 2);

      h += '<section class="blok"><h2>Uang masuk</h2>';
      if (s.izin.penjualan) {
        h += U.inputAngka({ kunci: 'angka:penjualan', masuk: 'angka', nilai: C.fmtNum(s.penjualan), label: 'Penjualan per bulan', awalan: 'Rp', data: { kunci: 'penjualan' }, galat: ui.galat['angka:penjualan'], bantu: 'Kasus awal ' + C.fmtJuta(D.kasus.penjualan) + ', sekitar 70% lewat QRIS. Ubah angkanya untuk mencoba kasus lain.' });
      } else h += U.izinKurang('penjualan');
      h += '</section>';

      h += '<section class="blok"><h2>Uang keluar yang terekam digital</h2>';
      if (s.izin.pembayaran) {
        h += '<ul class="daftar-pos">' + s.pos.map(function (p) { return barisPos(c, p); }).join('') + '</ul>';
        h += formTambah(c);
        h += '<div class="total-belanja">' + U.inputAngka({ kunci: 'angka:belanjaTotal', masuk: 'angka', nilai: C.fmtNum(s.belanjaTotal), label: 'Belanja operasional total per bulan', awalan: 'Rp', data: { kunci: 'belanjaTotal' }, galat: ui.galat['angka:belanjaTotal'], bantu: 'Termasuk belanja tunai. Selisihnya dengan pos digital adalah belanja yang belum terbaca.' }) + '</div>';
        if (hh.disesuaikan) h += '<p class="catatan awas">' + U.ikon('awas') + '<span>Total belanja lebih kecil dari jumlah pos digital, jadi dihitung sama dengan jumlah pos digital.</span></p>';
        h += '<div class="cakupan"><div class="meter" role="img" aria-label="Cakupan data ' + C.fmtPct(hh.cakupan, 0) + '"><span style="width:' + Math.min(100, hh.cakupan * 100).toFixed(1) + '%"></span></div>' +
          '<p><b>Cakupan data ' + C.fmtPct(hh.cakupan, 0) + '.</b> Terekam digital ' + C.fmtJuta(hh.terekam) + ' dari ' + C.fmtJuta(hh.belanjaTotal) + '; ' + C.fmtJuta(hh.tunai) + ' tunai belum terbaca.</p></div>';
        h += '<p class="catatan"><span>Menambah belanja yang tercatat sama pentingnya dengan menyempurnakan faktor emisi. Memindahkan pembelian tunai ke kanal digital menaikkan cakupan.</span></p>';
      } else h += U.izinKurang('pembayaran');
      h += '</section>';
      return h;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
