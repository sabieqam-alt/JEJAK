# JEJAK, simulasi aplikasi

Simulasi interaktif kerangka JEJAK (EIC 2026) untuk satu kasus hipotetis, sebuah warung makan. Tujuh langkah dalam tiga fase:

| Fase | Langkah |
|---|---|
| Penerapan | 1 Persetujuan, 2 Jejak transaksi, 3 Akun sederhana (SAK EMKM) |
| Perhitungan | 4 Estimasi dan label T1/T2/T3, 5 Jaminan data |
| Output | 6 Kartu Jejak Hijau, 7 Bagikan selektif |

Situs statis: HTML, CSS, dan JavaScript biasa. **Tanpa build, tanpa npm install, tanpa server.** Semua data tersimpan di browser pengguna (localStorage) dan tidak ada yang dikirim ke mana pun.

Kasus bawaan menghasilkan **1.163,0 kgCO₂e per bulan** (13,96 tCO₂e per tahun, 46,5 kg per Rp1 juta penjualan, rentang 863 sampai 1.651), sama dengan video simulasi.

## Menjalankan

| Cara | Perintah |
|---|---|
| Paling cepat | Klik dua kali `index.html`. Jalan tanpa internet. |
| Server lokal | `npm start`, lalu buka http://localhost:5173 (butuh Node 18 atau lebih baru, diuji di Node 22, tanpa instalasi apa pun). |
| Uji | `npm test` |

Untuk mengembangkan, sunting berkas lalu muat ulang halaman. Tidak ada langkah kompilasi.

## Deploy ke Vercel

`vercel.json` sudah mengatur situs ini sebagai situs statis (Framework "Other", tanpa build, folder akar disajikan apa adanya).

**Lewat GitHub (disarankan)**

1. Unggah folder ini ke repositori GitHub.
2. Di vercel.com buka *Add New, Project*, pilih repositori itu, lalu *Import*.
3. Biarkan *Framework Preset* di "Other", *Build Command* dan *Output Directory* kosong, lalu *Deploy*.
4. Setiap `git push` berikutnya otomatis memperbarui situs.

**Lewat CLI**

```
npm install -g vercel
vercel          # pertama kali: ikuti pertanyaannya, terima pengaturan bawaan
vercel --prod   # rilis ke alamat utama
```

Catatan: jangan menambahkan skrip `build` ke `package.json` kecuali Anda memang menambah langkah build, karena Vercel akan menjalankannya. Seluruh isi folder (termasuk `tests/` dan README ini) ikut tersaji sebagai berkas statis. Tidak ada rahasia di dalamnya.

## Peta berkas

```
index.html          Kerangka halaman. Urutan <script> penting (data, hitung, hash, store, ui, langkah, app).
vercel.json         Pengaturan Vercel.
package.json        Hanya dua skrip: npm start dan npm test.
assets/
  style.css         Semua gaya. Warna dan huruf ada di :root bagian atas.
  favicon.svg
  fonts/            Fira Sans dan Archivo Black (subset Latin) beserta lisensi OFL-nya.
src/
  data.js           SEMUA angka kasus, parameter, sumber, dan teks pilihan. Mulai dari sini.
  calc.js           Hitungan murni: emisi per pos, sensitivitas, laba rugi, format angka Indonesia.
  hash.js           SHA-256 dan rantai log (setiap entri membawa hash entri sebelumnya).
  store.js          State, aksi yang mengubahnya, isi Kartu, paket bagi, dan penyimpanan localStorage.
  ui.js             Pembantu tampilan: escape HTML, ikon, kolom angka, tombol navigasi, morph DOM.
  app.js            Penghubung: klik dan ketik menjadi aksi, aksi menjadi render. Routing #/1 sampai #/7.
  steps/            Satu berkas per langkah, l1-izin.js sampai l7-bagikan.js.
tests/              run.js (hitungan dan hash), store.test.js, render.test.js.
tools/serve.js      Server lokal tanpa dependensi, dipakai npm start.
```

## Cara kerja singkat

1. Pengguna mengklik atau mengetik. `app.js` menangkapnya lewat atribut di HTML: `data-act` (klik), `data-ch` (perubahan), `data-in` (mengetik), dan `data-form` (kirim formulir).
2. `app.js` memanggil `JEJAK.store.act('namaAksi', {...})`. Aksi di `store.js` adalah fungsi `(s, p, now) => s` yang menerima salinan state, mengubahnya, dan (untuk perubahan penting) menambah satu entri ke log berantai. Hasilnya disimpan ke localStorage.
3. `app.js` merender ulang: `JEJAK.langkah[n].render(c)` mengubah state menjadi teks HTML, lalu `morph` memperbarui DOM tanpa menghilangkan fokus kolom yang sedang diketik.

Hitungan emisi, sensitivitas, dan laba rugi hanya ada di `calc.js`, bukan di tampilan, jadi bisa diuji tanpa browser.

## Resep pengembangan

### Mengganti angka kasus atau parameter

Sunting hanya `src/data.js`: `kasus` (penjualan dan belanja total), `param` (kurs, tarif listrik, faktor jaringan), `pos` (nilai dan faktor tiap pos), `band` (rentang sensitivitas), `skenarioListrik`.

- Naikkan `versi` di `data.js` supaya state lama di browser (yang menyimpan angka lama) dibuang otomatis.
- Pastikan jumlah rupiah semua pos tidak melebihi `belanjaTotal`, karena selisihnya dihitung sebagai belanja tunai yang tidak terbaca.
- Sebagian uji mengunci angka kasus bawaan (1.163,0 dan kawan-kawannya) di `tests/run.js`, `tests/store.test.js`, dan `tests/render.test.js`. Uji itu akan gagal dengan sengaja saat angka berubah. Periksa hitungannya, lalu perbarui angka harapannya.
- Video dan esai memakai kasus bawaan. Jika angkanya diubah, tampilan aplikasi tidak lagi sama dengan materi itu.

### Menambah pos belanja bawaan

Tambahkan satu objek ke `pos` di `data.js`:

```js
{ id: 'minyak', nama: 'Minyak goreng', kat: 'bahan', rupiah: 1200000, tier: 'T1', slot: 3,
  faktorUSD: 0.5, sumberFaktor: 'Tulis sumber faktor di sini', cakupan: 'Cakupan 3 kat. 1' }
```

`slot` adalah nomor warna di `palet` (0 sampai 4), dan `maksPos` membatasi jumlah pos. Untuk lebih dari lima pos, tambahkan warna di `palet` dan periksa kontrasnya. Faktor yang Anda isi harus punya sumber nyata. Aplikasi ini sengaja tidak membawa faktor emisi karangan.

### Menambah izin

Tambahkan satu objek ke `izin` di `data.js`. Tombol di Langkah 1 dan state awalnya dibuat otomatis dari daftar itu. Jika izin itu menjadi syarat sebuah langkah, tambahkan namanya ke `SYARAT` di `store.js`. Naikkan `versi`.

### Menambah bidang yang bisa dibagikan

1. Tambahkan `{ id, label }` ke `bidang` di `data.js` (beri `butuh: 'penjualan'` jika bergantung pada izin penjualan).
2. Masukkan `id` itu ke `bidang` milik penerima yang seharusnya mendapat bidang tersebut.
3. Tulis satu baris di `paketBagi` (`store.js`) yang mengisi bidang itu, mengikuti baris-baris di sebelahnya.

### Menambah langkah

1. Salin `src/steps/l1-izin.js` menjadi `src/steps/l8-nama.js`, ganti nomor, `fase`, `judul`, dan isi `render`. Fase baru otomatis menjadi kelompok baru di rel kiri.
2. Daftarkan `<script src="src/steps/l8-nama.js">` di `index.html`, sebelum `src/app.js`.
3. Di `store.js`: ubah `JUMLAH_LANGKAH` dan tambahkan `8: { semua: [...] }` ke `SYARAT`.
4. `npm test`. Uji tampilan ikut mencakup langkah baru: merendernya di banyak keadaan, memeriksa escape HTML, dan memastikan setiap tombolnya punya penangan.

### Menambah tombol atau kolom isian

```js
// 1. Di render langkah:
'<button type="button" class="tombol" data-act="contoh" data-id="ayam">Contoh</button>'

// 2. Di app.js, di dalam objek KLIK:
contoh: function (el) { S.act('contohAksi', { id: el.dataset.id }); },

// 3. Di store.js, di dalam objek aksi:
contohAksi: function (s, p, now) {
  /* ubah s (sudah berupa salinan), lalu catat ke log bila perubahannya penting */
  return catat(s, now, 'contoh', 'Ringkasan satu baris untuk log', { id: p.id });
},
```

Untuk saklar dan pilihan pakai `data-ch="nama"` dan tambahkan `case 'nama':` di `saatUbah` (`app.js`). Untuk kolom angka yang diedit langsung pakai `data-in`, dan untuk formulir pakai `data-form` dengan penangan di objek `KIRIM`. Uji kontrak di `tests/render.test.js` akan gagal dan menyebut namanya jika ada atribut yang belum punya penangan.

### Mengubah tampilan

Warna, huruf, dan jarak ada di blok `:root` paling atas `assets/style.css`. Palet kategori (`palet` di `data.js`) sudah diperiksa dengan validator palet terhadap warna kertas aplikasi, dan nama pos selalu tampil di samping warnanya. Jika palet diganti, periksa ulang kontras dan keterbacaannya untuk buta warna. Animasi menghormati pengaturan "kurangi gerakan" dan layar cetak memuat Kartu saja (tombol *Cetak kartu* di Langkah 6, hasilnya bisa disimpan sebagai PDF lewat dialog cetak browser).

## Uji

`npm test` menjalankan pemeriksaan tanpa browser (saat ini 64):

- hitungan: total, rentang, sensitivitas, dan hitung ulang independen cocok dengan angka kasus;
- hash dan rantai log: perubahan satu entri terdeteksi;
- state dan aksi: izin, pos, naik tangga, bagi selektif, dan simpan lalu muat ulang;
- tampilan: setiap langkah tergambar di berbagai keadaan, teks pengguna di-escape, dan setiap `data-act`, `data-ch`, `data-in`, `data-form` punya penangan.

Alur klik lengkap di browser diuji terpisah di Chromium (desktop dan lebar ponsel). Safari dan Firefox belum diuji.

## Batasan yang perlu dijaga

- Kasusnya hipotetis. Bukan data warung nyata, bukan estimasi nasional, bukan audit atau sertifikasi.
- Faktor ayam dan beras berasal dari model input-output Amerika Serikat. Konversi dengan kurs pasar kemungkinan meremehkan emisi di Indonesia. Catatan ini tampil di Langkah 4 dan di Kartu.
- Rentang untuk pos T2 dan T3 (0,8 sampai 1,25 dan 0,9 sampai 1,1) adalah ilustrasi, bukan hasil pengukuran.
- Faktor T2 dan T3 tidak disediakan. Pengguna mengisinya sendiri beserta sumbernya, atau memakai angka "latihan" yang jelas palsu dan ditandai demikian di tape, Kartu, dan log.
- Rantai hash di sini menunjukkan cara kerja log yang ketahuan jika diubah. Log dan datanya sama-sama ada di browser, jadi orang yang menguasai browser itu bisa menulis ulang keduanya. Jaminan yang sebenarnya membutuhkan penjangkaran di luar perangkat pengguna.
- Fira Sans dan Archivo Black memakai SIL Open Font License 1.1 (lihat `assets/fonts/OFL-*.txt`). File fontnya subset Latin.
