/*
 * Server statis kecil untuk pengembangan lokal, tanpa dependensi.
 *   npm start            lalu buka http://localhost:5173
 *   PORT=8080 npm start  untuk port lain
 * Hanya melayani komputer Anda sendiri (127.0.0.1) dan tidak menyimpan cache, jadi setiap muat ulang
 * selalu memakai berkas terbaru. Aplikasinya sendiri juga bisa dibuka dengan klik dua kali index.html.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

const akar = path.join(__dirname, '..');
const port = Number(process.env.PORT) || 5173;
const jenis = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.woff': 'font/woff', '.woff2': 'font/woff2', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8'
};

function kirim(res, kode, tipe, isi) {
  res.writeHead(kode, { 'Content-Type': tipe, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(isi);
}

http.createServer(function (req, res) {
  let rel;
  try { rel = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch (e) { return kirim(res, 400, 'text/plain; charset=utf-8', 'Permintaan tidak valid'); }
  if (rel.indexOf('\0') >= 0) return kirim(res, 400, 'text/plain; charset=utf-8', 'Permintaan tidak valid');
  if (rel.slice(-1) === '/') rel += 'index.html';

  const berkas = path.normalize(path.join(akar, rel));
  if (berkas !== akar && berkas.indexOf(akar + path.sep) !== 0) return kirim(res, 403, 'text/plain; charset=utf-8', 'Dilarang');

  fs.readFile(berkas, function (err, isi) {
    if (err) return kirim(res, 404, 'text/plain; charset=utf-8', 'Tidak ditemukan: ' + rel);
    kirim(res, 200, jenis[path.extname(berkas).toLowerCase()] || 'application/octet-stream', isi);
  });
}).listen(port, '127.0.0.1', function () {
  console.log('JEJAK berjalan di http://localhost:' + port + '  (hentikan dengan Ctrl+C)');
});
