/*
 * Langkah 7: Bagikan selektif.
 * Pemilik usaha memilih penerima dan bidang demi bidang. Panel "Yang diterima" menampilkan isi paket
 * persis seperti yang dilihat penerima (S.paketBagi), jadi tidak ada data yang bocor lewat tampilan.
 * Aturan akses ada di store.js (aksi bagi dan bagiBidang), bukan di sini.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui, S = J.store, H = J.hash;

  function namaBidang(id) { return D.bidang.filter(function (b) { return b.id === id; })[0].label; }

  function panel(c, pn) {
    var s = c.s, b = s.bagi[pn.id], tid = 'pn-' + pn.id;
    var h = '<section class="penerima' + (b.aktif ? ' aktif' : '') + '" aria-labelledby="' + tid + '">';
    h += '<div class="penerima-kepala"><div><h3 id="' + tid + '">' + pn.nama + '</h3><p class="meta">Tujuan: ' + pn.tujuan + '.</p></div>' +
      '<label class="sakelar"><input type="checkbox" role="switch" data-ch="bagi" data-id="' + pn.id + '"' + (b.aktif ? ' checked' : '') + (!b.aktif && !b.bidang.length ? ' disabled' : '') + '>' +
      '<span class="geser" aria-hidden="true"></span><span class="teks"><b>Bagikan ke ' + pn.nama.toLowerCase() + '</b><span>' +
      (b.aktif ? 'Aktif sejak ' + U.waktu(b.sejak) : (b.bidang.length ? 'Belum dibagikan' : 'Pilih minimal satu bidang')) + '</span></span></label></div>';

    h += '<fieldset class="bidang"><legend>Bidang yang boleh dilihat ' + pn.nama.toLowerCase() + '</legend>';
    D.bidang.forEach(function (bd) {
      var terkunci = bd.butuh && !s.izin[bd.butuh], on = b.bidang.indexOf(bd.id) >= 0;
      var butuh = bd.butuh ? D.izin.filter(function (i) { return i.id === bd.butuh; })[0].pendek : '';
      h += '<label class="cek' + (terkunci ? ' mati' : '') + '"><input type="checkbox" data-ch="bagiBidang" data-id="' + pn.id + '" data-bidang="' + bd.id + '"' + (on ? ' checked' : '') + (terkunci ? ' disabled' : '') + '>' +
        '<span>' + bd.label + (terkunci ? '<small>Butuh izin ' + butuh + '</small>' : '') + '</span></label>';
    });
    h += '</fieldset>';

    h += '<div class="paket-wadah"><h4>Yang diterima ' + pn.nama.toLowerCase() + '</h4>';
    if (b.aktif) {
      var paket = JSON.stringify(S.paketBagi(s, pn.id, c.t), null, 2);
      h += '<pre class="paket" tabindex="0" aria-label="Isi data yang diterima ' + pn.nama.toLowerCase() + '"><code>' + U.esc(paket) + '</code></pre>';
    } else {
      h += '<p class="kosong">Belum ada akses. ' + pn.nama + ' tidak melihat apa pun dari usaha ini.</p>';
    }
    var tersembunyi = D.bidang.filter(function (bd) { return b.bidang.indexOf(bd.id) < 0; }).map(function (bd) { return namaBidang(bd.id).toLowerCase(); });
    if (b.aktif && tersembunyi.length) h += '<p class="meta">Tidak terlihat oleh ' + pn.nama.toLowerCase() + ': ' + tersembunyi.join(', ') + '.</p>';
    if (b.aktif) h += '<div class="aksi-baris"><button type="button" class="tombol sekunder" data-act="cabutBagi" data-id="' + pn.id + '">Cabut akses ' + pn.nama.toLowerCase() + '</button></div>';
    return h + '</div></section>';
  }

  J.langkah[7] = {
    n: 7, fase: 'Output', judul: 'Bagikan selektif',
    render: function (c) {
      var s = c.s, v = H.verifikasi(s.log);
      var h = U.kepala(this, 'Data tetap milik pemilik usaha. Bank dan pembeli korporat hanya menerima bidang yang dicentang, dan akses berhenti seketika ketika dicabut.');
      if (!c.ak.ok) return h + U.terkunci(c, 7);

      var aktif = D.penerima.filter(function (pn) { return s.bagi[pn.id].aktif; }).map(function (pn) { return pn.nama; });
      h += '<section class="blok"><h2>Pilih penerima dan bidangnya</h2>';
      if (!v.ok) h += '<p class="catatan awas">' + U.ikon('awas') + '<span>Rantai log putus di entri ' + v.di + '. Segel pada paket tidak berlaku sampai log dipulihkan di langkah 5.</span></p>';
      h += '<div class="penerima-banding">' + D.penerima.map(function (pn) { return panel(c, pn); }).join('') + '</div>';
      h += '<p class="catatan ' + (aktif.length ? 'ok' : '') + '">' + U.ikon(aktif.length ? 'cek' : 'info') + '<span>' +
        (aktif.length ? 'Akses aktif untuk: ' + aktif.join(' dan ') + '. Matikan sakelar atau cabut izin membagikan untuk menghentikannya.' : 'Belum ada akses aktif. Nyalakan sakelar salah satu penerima untuk melihat paket yang mereka terima.') + '</span></p>';
      h += '<div class="aksi-baris"><button type="button" class="tombol sekunder" data-act="izin" data-kunci="bagikan" data-nilai="0">Cabut izin membagikan</button>' +
        '<span class="petunjuk">Semua akses langsung berhenti, dan langkah ini terkunci lagi.</span></div></section>';

      h += '<section class="blok"><h2>Coba kasus lain</h2><p class="isi-teks">Ubah penjualan atau belanja di langkah 2, atau naikkan tangga data di langkah 4. Kartu di langkah 6 dan paket di sini ikut berubah, begitu juga segelnya.</p>' +
        '<div class="aksi-baris"><a class="tombol sekunder" href="#/2">Ubah angka di langkah 2</a><a class="tombol sekunder" href="#/4">Naik tangga di langkah 4</a><a class="tombol sekunder" href="#/6">Lihat Kartu</a></div></section>';
      return h;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
