/*
 * Langkah 6: Kartu Jejak Hijau (output).
 * Satu halaman yang bisa dicetak atau diunduh sebagai JSON. Isinya: angka, rentang, cakupan data,
 * rincian berlabel T1/T2/T3, sumber, dan segel yang berubah jika angka atau log berubah.
 * Tombol cetak dan unduh ditangani di app.js (data-act="cetak" dan "unduh").
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui, S = J.store, H = J.hash;
  var F = C.fmtNum, G = C.fmtRingkas, R = C.fmtRp, KG = U.KG, KGT = 'kgCO2e';

  /** Titik estimasi di dalam rentang rendah sampai tinggi. Angkanya ditulis di bawah batang, jadi tidak bisa bertabrakan. */
  function rentang(c) {
    var g = c.t.sens.gabungan, dasar = c.t.h.totalKg, atas = Math.max(g.hi, dasar) || 1;
    var x = function (v) { return Math.max(0, Math.min(100, v / atas * 100)); };
    var lo = x(g.lo), hi = x(g.hi), tengah = x(dasar);
    return '<div class="rentang" role="img" aria-label="Estimasi ' + F(dasar, 0) + ' ' + KGT + ' per bulan, rentang ' + F(g.lo, 0) + ' sampai ' + F(g.hi, 0) + '">' +
      '<div class="rentang-rel" aria-hidden="true"><span class="rentang-isi" style="left:' + lo.toFixed(1) + '%;width:' + (hi - lo).toFixed(1) + '%"></span><span class="rentang-titik" style="left:' + tengah.toFixed(1) + '%"></span></div>' +
      '<dl class="rentang-nilai"><div><dt>Rendah</dt><dd class="angka">' + F(g.lo, 0) + '</dd></div><div><dt>Estimasi</dt><dd class="angka"><b>' + F(dasar, 0) + '</b></dd></div><div><dt>Tinggi</dt><dd class="angka">' + F(g.hi, 0) + '</dd></div></dl></div>';
  }

  function rincian(c) {
    var s = c.s, hh = c.t.h;
    var t = '<div class="gulir"><table class="buku"><thead><tr><th scope="col">Pos</th><th scope="col">Cakupan</th><th scope="col">Label</th><th scope="col" class="angka">' + KG + ' per bulan</th><th scope="col" class="angka">Porsi</th><th scope="col">Cocok nota</th></tr></thead><tbody>';
    hh.rows.forEach(function (r) {
      var p = S.cariPos(s, r.id);
      t += '<tr><th scope="row"><span class="warna" style="--w:' + U.warna(r.slot) + '" aria-hidden="true"></span>' + U.esc(r.nama) + '</th><td>' + p.cakupan + '</td><td>' + U.tingkat(r.tier, p.latihan) + '</td>' +
        '<td class="angka">' + F(r.kg, 1) + '</td><td class="angka">' + C.fmtPct(r.porsi) + '</td>' +
        '<td>' + (s.sampel[r.id] ? '<span class="cocok">' + U.ikon('cek', 15) + 'Cocok</span>' : '<span class="redup">Belum</span>') + '</td></tr>';
    });
    return t + '</tbody><tfoot><tr class="total"><th scope="row" colspan="3">Total</th><td class="angka">' + F(hh.totalKg, 1) + '</td><td class="angka">100%</td><td></td></tr></tfoot></table></div>';
  }

  /** Diagram tornado: tiap baris menunjukkan seberapa jauh total bergeser jika satu faktor diubah ke ujung rentangnya. */
  function tornado(c) {
    var sens = c.t.sens, g = sens.gabungan;
    var baris = sens.faktor.concat([{ kunci: 'gabungan', label: 'Semua faktor bersamaan', ket: 'arah rendah dan tinggi sekaligus', lo: g.lo, hi: g.hi, loPct: g.loPct, hiPct: g.hiPct, gabungan: true }]);
    var mLo = Math.max.apply(null, baris.map(function (x) { return Math.abs(Math.min(0, x.loPct)); }));
    var mHi = Math.max.apply(null, baris.map(function (x) { return Math.max(0, x.hiPct); }));
    var tot = (mLo + mHi) || 1, sumbu = mLo / tot * 100;
    var h = '<ul class="tornado" aria-label="Pergeseran total emisi per faktor">';
    baris.forEach(function (x) {
      var wLo = Math.abs(Math.min(0, x.loPct)) / tot * 100, wHi = Math.max(0, x.hiPct) / tot * 100;
      var judul = F(x.lo, 0) + ' sampai ' + F(x.hi, 0) + ' ' + KGT + ' per bulan';
      h += '<li class="tr' + (x.gabungan ? ' gabungan' : '') + '"><div class="tr-label"><b>' + x.label + '</b><span>' + x.ket + '</span><span class="tr-abs">' + F(x.lo, 0) + ' sampai ' + F(x.hi, 0) + ' ' + KG + '</span></div>' +
        '<span class="tr-nilai angka lo">' + C.fmtTanda(x.loPct) + '</span>' +
        '<div class="tr-rel" title="' + judul + '" aria-hidden="true"><span class="tr-sumbu" style="left:' + sumbu.toFixed(1) + '%"></span>' +
        '<span class="tr-lo" style="right:' + (100 - sumbu).toFixed(1) + '%;width:' + wLo.toFixed(1) + '%"></span>' +
        '<span class="tr-hi" style="left:' + sumbu.toFixed(1) + '%;width:' + wHi.toFixed(1) + '%"></span></div>' +
        '<span class="tr-nilai angka hi">' + C.fmtTanda(x.hiPct) + '</span></li>';
    });
    return h + '</ul><p class="meta">Biru: total lebih rendah dari estimasi. Terakota: total lebih tinggi. Rentang T2 dan T3 adalah ilustrasi, bukan hasil pengukuran.</p>';
  }

  function sumber(c) {
    var s = c.s, h = '<ul class="sumber-daftar">';
    h += '<li><b>Kurs</b> Rp' + G(s.param.kurs, 2) + ' per USD. ' + D.paramInfo.kurs.sumber + '.</li>';
    h += '<li><b>Tarif listrik</b> Rp' + G(s.param.tarif, 2) + ' per kWh. ' + D.paramInfo.tarif.sumber + '.</li>';
    h += '<li><b>Faktor listrik jaringan</b> ' + G(s.param.jaringan, 4) + ' kgCO<sub>2</sub> per kWh. ' + D.paramInfo.jaringan.sumber + '.</li>';
    s.pos.filter(function (p) { return p.kat === 'bahan'; }).forEach(function (p) {
      if (p.tier === 'T1') h += '<li><b>' + U.esc(p.nama) + '</b> ' + G(p.faktorUSD, 4) + ' ' + KG + ' per USD belanja. ' + U.esc(p.sumberFaktor) + '.</li>';
      else h += '<li><b>' + U.esc(p.nama) + '</b> ' + G(p.qty, 2) + ' ' + U.esc(p.unit) + ' × ' + G(p.fq, 4) + ' ' + KG + ' per ' + U.esc(p.unit) + '. ' + U.esc(p.sumberFq) + '.' + (p.latihan ? ' <span class="latihan">latihan</span>' : '') + '</li>';
    });
    return h + '</ul>';
  }

  function kartu(c) {
    var s = c.s, t = c.t, hh = t.h, v = H.verifikasi(s.log);
    var kode = H.segelPendek(S.segelKartu(s, t));
    var tgl = U.tanggal(s.log[s.log.length - 1].t);
    var o = '<article class="kartu" aria-labelledby="judul-kartu">';
    o += '<header class="kartu-kepala"><div class="kartu-merek">' + U.daun(44) + '<div><p class="kartu-jenis">Kartu Jejak Hijau</p><h2 id="judul-kartu">' + U.esc(s.usaha || 'Usaha tanpa nama') + '</h2>' +
      '<p class="meta">Estimasi per bulan, kasus simulasi. Disusun ' + tgl + '.</p></div></div>' + U.cap(kode, v.ok, 'kartu') + '</header>';
    if (!v.ok) o += '<p class="catatan awas">' + U.ikon('awas') + '<span>Rantai log putus di entri ' + v.di + '. Segel di kartu ini tidak berlaku sampai log dipulihkan di langkah 5.</span></p>';

    o += '<div class="kartu-angka"><p class="besar"><span class="n angka">' + F(hh.totalKg, 1) + '</span> <span class="sat">' + KG + ' per bulan</span></p>' + rentang(c) + '</div>';

    o += '<dl class="fakta">' +
      '<div><dt>Setahun (× 12)</dt><dd><span class="n angka">' + F(hh.tahunTon, 2) + '</span> t' + U.CO2E + '</dd></div>' +
      '<div><dt>Intensitas</dt><dd>' + (hh.intensitas == null ? '<span class="redup">Tidak dihitung, izin baca penjualan belum diberikan</span>' : '<span class="n angka">' + F(hh.intensitas, 1) + '</span> ' + KG + ' per Rp1 juta penjualan') + '</dd></div>' +
      '<div><dt>Cakupan data</dt><dd><span class="n angka">' + C.fmtPct(hh.cakupan, 0) + '</span><span class="rinci-kecil">' + C.fmtJuta(hh.terekam) + ' terekam digital dari ' + C.fmtJuta(hh.belanjaTotal) + ' belanja. ' + C.fmtJuta(hh.tunai) + ' tunai belum terbaca.</span></dd></div></dl>';

    o += '<section class="kartu-bagian"><h3>Rincian per pos</h3>' + rincian(c) + '</section>';
    o += '<section class="kartu-bagian"><h3>Seberapa pasti angka ini</h3><p class="isi-teks">Estimasi ini bukan satu titik pasti. Rentang ' + F(t.sens.gabungan.lo, 0) + ' sampai ' + F(t.sens.gabungan.hi, 0) + ' ' + KG + ' muncul ketika semua faktor digeser ke ujung rentangnya sekaligus. Faktor yang paling berpengaruh ada di baris paling atas.</p>' + tornado(c) + '</section>';
    o += '<section class="kartu-bagian"><h3>Parameter dan sumber</h3>' + sumber(c) + '</section>';
    o += '<section class="kartu-bagian"><h3>Catatan</h3><p class="isi-teks">' + D.catatanJujur + '</p><p class="isi-teks">' + D.disclaimer + '</p></section>';
    o += '<footer class="kartu-kaki"><p>Segel <b>' + kode + '</b> dihitung dari isi kartu dan kepala log (' + s.log.length + ' entri, <code>' + S.kepalaLog(s).slice(0, 12) + '</code>). Mengubah satu angka atau satu entri log mengubah segel.</p></footer></article>';
    return o;
  }

  function tindakan() {
    return '<section class="blok tindakan"><h2>Simpan atau cetak</h2><div class="aksi-baris">' +
      '<button type="button" class="tombol utama" data-act="cetak">' + U.ikon('cetak', 18) + 'Cetak kartu</button>' +
      '<button type="button" class="tombol sekunder" data-act="unduh">' + U.ikon('unduh', 18) + 'Unduh JSON</button></div>' +
      '<p class="meta">Cetak hanya memuat kartu, satu sampai dua halaman. Berkas JSON memuat angka dan segel yang sama, dalam bentuk yang mudah dibaca program lain.</p></section>';
  }

  J.langkah[6] = {
    n: 6, fase: 'Output', judul: 'Kartu Jejak Hijau',
    render: function (c) {
      var h = U.kepala(this, 'Hasil akhirnya satu kartu yang bisa dibaca bank atau pembeli: angka, rentang ketidakpastiannya, cakupan datanya, dan segel yang berubah jika angka atau log berubah.');
      if (!c.ak.ok) return h + U.terkunci(c, 6);
      return h + kartu(c) + tindakan();
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
