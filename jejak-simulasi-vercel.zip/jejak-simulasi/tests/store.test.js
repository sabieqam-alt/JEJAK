/* Uji untuk store.js (aksi murni). Dimuat otomatis oleh tests/run.js */
'use strict';
const path = require('path');

module.exports = function ({ uji, eq, dekat, klon }) {
  const J = globalThis.JEJAK;
  require(path.join(__dirname, '..', 'src', 'store.js'));
  const S = J.store, H = J.hash, C = J.calc;
  const T = (n) => '2026-11-26T09:' + String(10 + n).padStart(2, '0') + ':00.000Z';
  const aw = () => S.stateAwal(T(0));
  const ap = (s, nama, p, n) => S.terapkan(s, nama, p, T(n || 1));

  console.log('\nState dan log (store)');
  uji('state awal: izin kosong, log berisi satu entri valid', () => {
    const s = aw();
    eq(s.log.length, 1); eq(H.verifikasi(s.log).ok, true);
    eq(Object.values(s.izin).some(Boolean), false);
  });
  uji('izin memberi akses langkah secara bertahap dan tiap izin masuk log', () => {
    let s = aw();
    eq(S.akses(s, 2).ok, false);
    s = ap(s, 'izin', { kunci: 'penjualan', nilai: true });
    eq(S.akses(s, 2).ok, true); eq(S.akses(s, 3).ok, false); eq(S.akses(s, 3).kurang.join(), 'pembayaran');
    s = ap(s, 'izin', { kunci: 'pembayaran', nilai: true });
    eq(S.akses(s, 3).ok, true); eq(S.akses(s, 4).ok, false);
    s = ap(s, 'izin', { kunci: 'estimasi', nilai: true });
    eq(S.akses(s, 6).ok, true); eq(S.akses(s, 7).ok, false);
    eq(s.log.length, 4); eq(H.verifikasi(s.log).ok, true);
  });
  uji('memberi izin yang sama dua kali tidak menambah log', () => {
    let s = ap(aw(), 'izin', { kunci: 'penjualan', nilai: true });
    const n = s.log.length;
    s = ap(s, 'izin', { kunci: 'penjualan', nilai: true });
    eq(s.log.length, n);
  });
  uji('izinSemua membuka semua langkah', () => {
    const s = ap(aw(), 'izinSemua');
    for (let n = 1; n <= S.JUMLAH_LANGKAH; n++) eq(S.akses(s, n).ok, true, 'langkah ' + n);
    eq(s.log.length, 5);
  });
  uji('mengetik (sunyi) mengubah angka tanpa log; menyelesaikan edit mencatat satu entri', () => {
    let s = ap(aw(), 'izinSemua'); const n = s.log.length;
    s = ap(s, 'pos', { id: 'ayam', bidang: 'rupiah', nilai: 7, sunyi: true });
    s = ap(s, 'pos', { id: 'ayam', bidang: 'rupiah', nilai: 7000000, sunyi: true });
    eq(s.log.length, n); eq(S.cariPos(s, 'ayam').rupiah, 7000000);
    s = ap(s, 'pos', { id: 'ayam', bidang: 'rupiah', nilai: 7000000, sebelum: 6000000 });
    eq(s.log.length, n + 1);
    eq(s.log[n].ringkas, 'Ayam: belanja diubah dari Rp6.000.000 menjadi Rp7.000.000');
  });
  uji('angka tidak valid (≤0 atau NaN) ditolak', () => {
    const s0 = ap(aw(), 'izinSemua');
    const s1 = ap(s0, 'pos', { id: 'ayam', bidang: 'rupiah', nilai: -5 });
    const s2 = ap(s1, 'angka', { kunci: 'kurs', nilai: NaN });
    eq(S.cariPos(s2, 'ayam').rupiah, 6000000); eq(s2.param.kurs, 18100);
  });
  uji('turunan(s) pada kasus awal = 1.163,0 kgCO2e dan hasil independen sama', () => {
    const t = S.turunan(aw());
    eq(C.fmtNum(t.h.totalKg, 1), '1.163,0'); dekat(t.ind.total, t.h.totalKg, 1e-9);
  });

  console.log('\nPos tambahan dan naik tangga (store)');
  uji('cekPosBaru: nama kosong, angka salah, faktor tanpa sumber → ditolak', () => {
    const s = aw();
    eq(S.cekPosBaru(s, { nama: '', kat: 'bahan', rupiah: '1.000.000' }).ok, false);
    eq(S.cekPosBaru(s, { nama: 'Minyak', kat: 'bahan', rupiah: 'abc' }).ok, false);
    eq(S.cekPosBaru(s, { nama: 'Minyak', kat: 'bahan', rupiah: '1.000.000', faktorPilih: 'lain', faktorUSD: '0,5', sumber: '' }).ok, false);
    eq(S.cekPosBaru(s, { nama: 'ayam', kat: 'bahan', rupiah: '1.000.000', faktorPilih: 'unggas' }).ok, false, 'nama kembar');
  });
  uji('tambahPos: faktor dari pilihan atau isian + sumber; warna slot berikutnya; batas maksimum', () => {
    let s = aw();
    s = ap(s, 'tambahPos', { nama: 'Minyak goreng', kat: 'bahan', rupiah: '1.200.000', faktorPilih: 'lain', faktorUSD: '0,5', sumber: 'Faktor contoh pengguna' });
    const m = S.cariPos(s, 'minyak-goreng');
    eq(m.slot, 3); eq(m.tier, 'T1'); eq(m.faktorUSD, 0.5);
    s = ap(s, 'tambahPos', { nama: 'Gas', kat: 'listrik', rupiah: '500.000' });
    eq(s.pos.length, 5);
    eq(S.cekPosBaru(s, { nama: 'Lagi', kat: 'listrik', rupiah: '1' }).ok, false, 'maksimal 5');
    eq(H.verifikasi(s.log).ok, true);
  });
  uji('hapusPos hanya untuk pos tambahan', () => {
    let s = ap(aw(), 'tambahPos', { nama: 'Telur', kat: 'bahan', rupiah: '800.000', faktorPilih: 'unggas' });
    s = ap(s, 'hapusPos', { id: 'ayam' }); eq(!!S.cariPos(s, 'ayam'), true);
    s = ap(s, 'hapusPos', { id: 'telur' }); eq(!!S.cariPos(s, 'telur'), false);
  });
  uji('naikTangga wajib kuantitas, faktor, dan sumber; hasil ikut berubah dan tercatat', () => {
    let s = aw();
    eq(S.cekNaikTangga(s, { id: 'ayam', tier: 'T2', qty: '150', fq: '1', sumber: '' }).ok, false);
    eq(S.cekNaikTangga(s, { id: 'listrik', tier: 'T2', qty: '150', fq: '1', sumber: 'x y z' }).ok, false);
    s = ap(s, 'naikTangga', { id: 'ayam', tier: 'T2', qty: '150', fq: '1', unit: 'kg', sumber: 'Angka latihan', latihan: true });
    const t = S.turunan(s);
    eq(S.cariPos(s, 'ayam').tier, 'T2'); dekat(t.h.rows[1].kg, 150, 1e-9);
    eq(s.log[s.log.length - 1].jenis, 'naik_tangga');
    s = ap(s, 'turunTangga', { id: 'ayam' });
    eq(S.cariPos(s, 'ayam').tier, 'T1'); eq(C.fmtNum(S.turunan(s).h.totalKg, 1), '1.163,0');
  });

  console.log('\nPembagian selektif dan keamanan log (store)');
  uji('bagi hanya jalan jika izin berbagi ada; mencabut izin memutus semua akses', () => {
    let s = aw();
    s = ap(s, 'bagi', { id: 'bank', aktif: true }); eq(s.bagi.bank.aktif, false);
    s = ap(s, 'izinSemua');
    s = ap(s, 'bagi', { id: 'bank', aktif: true }); s = ap(s, 'bagi', { id: 'pembeli', aktif: true });
    eq(s.bagi.bank.aktif && s.bagi.pembeli.aktif, true);
    s = ap(s, 'izin', { kunci: 'bagikan', nilai: false });
    eq(s.bagi.bank.aktif || s.bagi.pembeli.aktif, false);
    eq(H.verifikasi(s.log).ok, true);
  });
  uji('paket data hanya berisi bidang yang dicentang dan membawa segel', () => {
    let s = ap(aw(), 'izinSemua');
    const t = S.turunan(s);
    const bank = S.paketBagi(s, 'bank', t);
    eq(bank.total_kgco2e_per_bulan, 1163); eq('penjualan_rp_per_bulan' in bank, false); eq('rincian' in bank, false);
    s = ap(s, 'bagiBidang', { id: 'bank', bidang: 'penjualan', nilai: true });
    eq(S.paketBagi(s, 'bank', S.turunan(s)).penjualan_rp_per_bulan, 25000000);
    eq(/^[0-9A-F]{4}-[0-9A-F]{4}$/.test(bank.segel), true);
  });
  uji('segel kartu berubah ketika angka berubah', () => {
    let s = ap(aw(), 'izinSemua');
    const a = S.segelKartu(s, S.turunan(s));
    s = ap(s, 'pos', { id: 'beras', bidang: 'rupiah', nilai: 3500000, sebelum: 3000000 });
    eq(a === S.segelKartu(s, S.turunan(s)), false);
  });
  uji('manipulasi log terdeteksi dan bisa dipulihkan', () => {
    let s = ap(aw(), 'izinSemua');
    s = ap(s, 'rusak', { i: 3 });
    const v = H.verifikasi(s.log); eq(v.ok, false); eq(v.di, 3);
    s = ap(s, 'pulihkan'); eq(H.verifikasi(s.log).ok, true);
  });

  uji('mencabut izin penjualan menghapus bidang yang bergantung padanya dan tidak bisa dicentang lagi', () => {
    let s = ap(aw(), 'izinSemua');
    s = ap(s, 'bagiBidang', { id: 'bank', bidang: 'penjualan', nilai: true });
    eq(s.bagi.bank.bidang.indexOf('penjualan') >= 0, true);
    s = ap(s, 'izin', { kunci: 'penjualan', nilai: false });
    eq(s.bagi.bank.bidang.indexOf('penjualan') < 0 && s.bagi.bank.bidang.indexOf('intensitas') < 0, true);
    s = ap(s, 'bagiBidang', { id: 'bank', bidang: 'laba', nilai: true });
    eq(s.bagi.bank.bidang.indexOf('laba'), -1);
    eq(S.turunan(s).h.intensitas, null);
  });
  uji('state yang disimpan lalu dibaca kembali tetap valid (JSON bolak-balik)', () => {
    const s = ap(ap(aw(), 'izinSemua'), 'tambahPos', { nama: 'Telur', kat: 'bahan', rupiah: '800.000', faktorPilih: 'unggas' });
    const t = klon(s); eq(H.verifikasi(t.log).ok, true); eq(S.segelKartu(t, S.turunan(t)), S.segelKartu(s, S.turunan(s)));
  });
};
