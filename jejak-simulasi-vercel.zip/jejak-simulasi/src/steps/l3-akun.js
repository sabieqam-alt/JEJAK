/*
 * Langkah 3: Akun sederhana (SAK EMKM) → laporan laba rugi minimal.
 * Pemetaan pos ke akun ada di fungsi akunUntuk(); ubah di sini bila ingin nama akun lain.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, C = J.calc, U = J.ui;

  function akunUntuk(p) { return p.kat === 'listrik' ? 'Beban listrik' : 'Beban bahan baku'; }

  J.langkah[3] = {
    n: 3, fase: 'Penerapan', judul: 'Akun sederhana',
    render: function (c) {
      var s = c.s, lr = c.t.lr;
      var h = U.kepala(this, 'Setiap transaksi dikategorikan otomatis ke akun sederhana SAK EMKM. Hasil sampingannya adalah laporan laba rugi minimal, tanpa pembukuan tambahan dari pemilik.');
      if (!c.ak.ok) return h + U.terkunci(c, 3);

      var namaBahan = s.pos.filter(function (p) { return p.kat === 'bahan'; }).map(function (p) { return U.esc(p.nama.toLowerCase()); }).join(', ');

      h += '<section class="blok"><h2>Dari transaksi ke akun</h2><div class="gulir"><table class="buku"><thead><tr><th scope="col">Transaksi yang terbaca</th><th scope="col">Akun sederhana</th><th scope="col" class="angka">Jumlah per bulan</th></tr></thead><tbody>';
      h += '<tr><th scope="row">Penjualan</th><td>Penjualan</td><td class="angka">' + C.fmtRp(lr.penjualan) + '</td></tr>';
      s.pos.forEach(function (p) {
        h += '<tr><th scope="row"><span class="warna" style="--w:' + U.warna(p.slot) + '" aria-hidden="true"></span>' + U.esc(p.nama) + '</th><td>' + akunUntuk(p) + '</td><td class="angka">' + C.fmtRp(p.rupiah) + '</td></tr>';
      });
      h += '<tr class="redup"><th scope="row">Belanja tunai yang tidak terbaca</th><td>Belum dikategorikan</td><td class="angka">' + C.fmtRp(lr.tunai) + '</td></tr>';
      h += '</tbody></table></div></section>';

      h += '<section class="blok"><h2>Laporan laba rugi minimal</h2><div class="gulir"><table class="buku lr"><tbody>' +
        '<tr class="kepala-lr"><th scope="row">Penjualan</th><td class="angka">' + C.fmtRp(lr.penjualan) + '</td></tr>' +
        '<tr><th scope="row" class="masuk">Beban bahan baku' + (namaBahan ? ' (' + namaBahan + ')' : '') + '</th><td class="angka">' + C.fmtRp(lr.bahan) + '</td></tr>' +
        '<tr><th scope="row" class="masuk">Beban listrik</th><td class="angka">' + C.fmtRp(lr.listrik) + '</td></tr>' +
        '<tr><th scope="row" class="masuk">Belanja tunai belum dikategorikan</th><td class="angka">' + C.fmtRp(lr.tunai) + '</td></tr>' +
        '<tr class="subtotal"><th scope="row">Total belanja operasional</th><td class="angka">' + C.fmtRp(lr.totalBeban) + '</td></tr>' +
        '<tr class="total"><th scope="row">Selisih penjualan dan belanja</th><td class="angka">' + C.fmtRp(lr.laba) + '</td></tr>' +
        '</tbody></table></div>' +
        '<p class="isi-teks">Selisih ' + (lr.marjin == null ? '' : 'setara ' + C.fmtPct(lr.marjin, 0) + ' dari penjualan ') + 'bersifat indikatif: hanya memuat yang terbaca atau dicatat di langkah 2, dan belum memuat beban lain yang tidak terekam.</p></section>';

      h += '<section class="blok"><p class="catatan"><span>SAK EMKM bukan beban tambahan bagi pemilik usaha. Laporan ini hasil sampingan otomatis dari transaksi yang sudah ada.</span></p></section>';
      return h;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
