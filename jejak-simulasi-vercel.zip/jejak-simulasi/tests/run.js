/*
 * Uji otomatis tanpa pustaka tambahan.   Jalankan:  node tests/run.js
 * Setiap uji mencetak ✓ atau ✗; kode keluar 1 jika ada yang gagal.
 */
'use strict';
const path = require('path');
const nodeCrypto = require('crypto');

const src = (f) => path.join(__dirname, '..', 'src', f);
require(src('data.js'));
const C = require(src('calc.js'));
const H = require(src('hash.js'));
const D = globalThis.JEJAK.data;

let lulus = 0, gagal = 0;
function uji(nama, fn) {
  try { fn(); lulus++; console.log('  ✓ ' + nama); }
  catch (e) { gagal++; console.log('  ✗ ' + nama + '\n      ' + e.message); }
}
function eq(a, b, pesan) { if (a !== b) throw new Error((pesan || '') + ' diharapkan ' + JSON.stringify(b) + ', dapat ' + JSON.stringify(a)); }
function dekat(a, b, tol, pesan) { if (Math.abs(a - b) > tol) throw new Error((pesan || '') + ' diharapkan ≈' + b + ' (±' + tol + '), dapat ' + a); }
function klon(x) { return JSON.parse(JSON.stringify(x)); }

const kasus = () => ({ penjualan: D.kasus.penjualan, belanjaTotal: D.kasus.belanjaTotal, param: klon(D.param), pos: klon(D.pos) });

console.log('\nFormat angka');
uji('fmtNum memakai titik ribuan dan koma desimal', () => {
  eq(C.fmtNum(1163.03, 1), '1.163,0');
  eq(C.fmtNum(13.9564, 2), '13,96');
  eq(C.fmtNum(1500000), '1.500.000');
  eq(C.fmtNum(0), '0');
});
uji('minus memakai tanda − dan tidak muncul "−0,0"', () => {
  eq(C.fmtNum(-11.24, 1), '−11,2');
  eq(C.fmtNum(-0.01, 1), '0,0');
});
uji('fmtRp, fmtJuta, fmtPct, fmtTanda', () => {
  eq(C.fmtRp(1500000), 'Rp1.500.000');
  eq(C.fmtRp(-250), '−Rp250');
  eq(C.fmtJuta(10500000), 'Rp10,5 juta');
  eq(C.fmtJuta(25000000), 'Rp25 juta');
  eq(C.fmtPct(0.777), '77,7%');
  eq(C.fmtTanda(0.2234), '+22,3%');
  eq(C.fmtTanda(-0.1123), '−11,2%');
  eq(C.fmtTanda(0), '0,0%');
});

console.log('\nMembaca angka ketikan');
uji('format Indonesia dan Inggris', () => {
  eq(C.parseNum('1.500.000'), 1500000);
  eq(C.parseNum('Rp 6.000.000'), 6000000);
  eq(C.parseNum('1.444,70'), 1444.7);
  eq(C.parseNum('1444.7'), 1444.7);
  eq(C.parseNum('0,87'), 0.87);
  eq(C.parseNum('0.391'), 0.391);
  eq(C.parseNum('18.100'), 18100);
  eq(C.parseNum('25'), 25);
});
uji('menolak teks yang bukan angka', () => {
  ['', 'abc', '1,2,3', '1,444.70', '12.34.56', '--5'].forEach((s) => eq(Number.isNaN(C.parseNum(s)), true, JSON.stringify(s)));
});
uji('format lalu baca kembali memberi angka yang sama', () => {
  [0, 7, 1500000, 1444.7, 0.391, 1163.03].forEach((n) => dekat(C.parseNum(C.fmtNum(n, 3)), n, 0.0006, String(n)));
});

console.log('\nKasus warung makan (Modul 4)');
const dasar = C.hitungSemua(kasus());
const r = Object.fromEntries(dasar.rows.map((x) => [x.id, x]));
uji('langkah listrik: 1.038,3 kWh → 903,3 kgCO2e', () => {
  dekat(r.listrik.kwh, 1038.3, 0.05); dekat(r.listrik.kg, 903.3, 0.05);
});
uji('langkah ayam dan beras: USD 331,5 / 165,7 → 129,6 / 130,1 kgCO2e', () => {
  dekat(r.ayam.usd, 331.5, 0.05); dekat(r.ayam.kg, 129.6, 0.05);
  dekat(r.beras.usd, 165.7, 0.05); dekat(r.beras.kg, 130.1, 0.05);
});
uji('total 1.163,0 kgCO2e/bulan, 13,96 tCO2e/tahun, 46,5 kg per Rp1 juta', () => {
  eq(C.fmtNum(dasar.totalKg, 1), '1.163,0');
  eq(C.fmtNum(dasar.tahunTon, 2), '13,96');
  eq(C.fmtNum(dasar.intensitas, 1), '46,5');
});
uji('porsi 77,7% / 11,1% / 11,2%; cakupan data 70%; tunai Rp4,5 juta', () => {
  eq(C.fmtPct(r.listrik.porsi), '77,7%'); eq(C.fmtPct(r.ayam.porsi), '11,1%'); eq(C.fmtPct(r.beras.porsi), '11,2%');
  eq(C.fmtPct(dasar.cakupan, 0), '70%'); eq(dasar.terekam, 10500000); eq(dasar.tunai, 4500000);
});
uji('latihan Modul 4: token listrik Rp2 juta → 1.384 kWh, 1.204 kg, total ≈1.464, porsi listrik 82%', () => {
  const k = kasus(); k.pos[0].rupiah = 2000000;
  const h = C.hitungSemua(k);
  dekat(h.rows[0].kwh, 1384.4, 0.1); dekat(h.rows[0].kg, 1204.4, 0.1);
  dekat(h.totalKg, 1464.1, 0.1); dekat(h.totalKg - dasar.totalKg, 301.1, 0.2);
  eq(C.fmtPct(h.rows[0].porsi, 0), '82%');
});
uji('belanja total lebih kecil dari pos digital → disesuaikan, cakupan tidak lewat 100%', () => {
  const k = kasus(); k.belanjaTotal = 5000000;
  const h = C.hitungSemua(k);
  eq(h.disesuaikan, true); eq(h.belanjaTotal, 10500000); eq(h.cakupan, 1);
});

console.log('\nSensitivitas (Modul 5)');
const sn = C.sensitivitas(kasus(), D.band);
const sk = Object.fromEntries(sn.faktor.map((x) => [x.kunci, x]));
uji('urutan tornado: C3, tarif, jaringan, kurs', () => {
  eq(sn.faktor.map((x) => x.kunci).join(','), 'c3,tarif,jaringan,kurs');
});
uji('faktor Cakupan 3 ×0,5–×2 → 1.033 / 1.423 (−11,2% / +22,3%)', () => {
  eq(Math.round(sk.c3.lo), 1033); eq(Math.round(sk.c3.hi), 1423); eq(C.fmtTanda(sk.c3.loPct), '−11,2%'); eq(C.fmtTanda(sk.c3.hiPct), '+22,3%');
});
uji('tarif ±10% → 1.081 / 1.263', () => { eq(Math.round(sk.tarif.lo), 1081); eq(Math.round(sk.tarif.hi), 1263); });
uji('faktor jaringan ±10% → 1.073 / 1.253', () => { eq(Math.round(sk.jaringan.lo), 1073); eq(Math.round(sk.jaringan.hi), 1253); });
uji('kurs ±5% → 1.151 / 1.177', () => { eq(Math.round(sk.kurs.lo), 1151); eq(Math.round(sk.kurs.hi), 1177); });
uji('rentang gabungan 863–1.651 (−25,8% / +41,9%)', () => {
  eq(Math.round(sn.gabungan.lo), 863); eq(Math.round(sn.gabungan.hi), 1651);
  eq(C.fmtTanda(sn.gabungan.loPct), '−25,8%'); eq(C.fmtTanda(sn.gabungan.hiPct), '+41,9%');
});
uji('naik tangga: pos T2 memakai pengali t2 dan keluar dari pengali C3', () => {
  const k = kasus();
  Object.assign(k.pos[1], { tier: 'T2', qty: 100, fq: 2, unit: 'kg' });   // angka uji, bukan faktor resmi
  const h = C.hitungSemua(k);
  dekat(h.rows[1].kg, 200, 1e-9);
  const s = C.sensitivitas(k, D.band);
  eq(s.faktor.some((x) => x.kunci === 't2'), true);
  const tanpaT2 = C.hitungSemua(k, { c3: 2 }).rows[1].kg;
  dekat(tanpaT2, 200, 1e-9, 'pengali C3 tidak boleh memengaruhi pos T2');
});
uji('tanpa pos T1, baris C3 dan kurs hilang', () => {
  const k = kasus(); k.pos = [k.pos[0]];
  eq(C.sensitivitas(k, D.band).faktor.map((x) => x.kunci).join(','), 'tarif,jaringan');
});

console.log('\nPemeriksa independen dan laba rugi');
uji('hitung ulang independen sama dengan hasil utama', () => {
  const ind = C.hitungUlangIndependen(kasus());
  dekat(ind.total, dasar.totalKg, 1e-9);
  ind.rows.forEach((x, i) => dekat(x.kg, dasar.rows[i].kg, 1e-9, x.id));
});
uji('laba rugi: penjualan 25 juta − belanja 15 juta = 10 juta (marjin 40%)', () => {
  const lr = C.labaRugi(kasus());
  eq(lr.bahan, 9000000); eq(lr.listrik, 1500000); eq(lr.tunai, 4500000); eq(lr.laba, 10000000); eq(C.fmtPct(lr.marjin, 0), '40%');
});

console.log('\nSHA-256 dan log berantai');
uji('vektor uji baku', () => {
  eq(H.sha256(''), 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  eq(H.sha256('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
});
uji('sama dengan crypto bawaan Node (UTF-8 dan batas padding)', () => {
  const contoh = ['Rp1.500.000 − ×÷ 🍗', 'ä ö ü – “kutip”'];
  for (const n of [54, 55, 56, 57, 63, 64, 65, 119, 120, 121, 1000]) contoh.push('x'.repeat(n));
  for (const s of contoh) eq(H.sha256(s), nodeCrypto.createHash('sha256').update(s, 'utf8').digest('hex'), 'panjang ' + s.length);
});
uji('kanon: urutan kunci tidak memengaruhi hasil', () => {
  eq(H.kanon({ b: 1, a: [2, { d: 4, c: 3 }] }), H.kanon({ a: [2, { c: 3, d: 4 }], b: 1 }));
});
function rantai(n) {
  let log = [];
  for (let i = 1; i <= n; i++) log = H.tambah(log, { t: '2026-11-26T09:0' + i + ':00Z', jenis: 'uji', ringkas: 'entri ' + i, data: { i } });
  return log;
}
uji('rantai utuh lolos verifikasi', () => { const v = H.verifikasi(rantai(5)); eq(v.ok, true); eq(v.jumlah, 5); });
uji('mengubah isi entri 3 → putus di entri 3', () => {
  const log = klon(rantai(5)); log[2].ringkas = 'dipalsukan';
  const v = H.verifikasi(log); eq(v.ok, false); eq(v.di, 3);
});
uji('mengubah entri 3 lalu menghitung ulang sidik jarinya → ketahuan di entri 4', () => {
  const log = klon(rantai(5)); log[2].data = { i: 99 };
  const tanpaHash = Object.assign({}, log[2]); delete tanpaHash.hash;
  log[2].hash = H.tambah(log.slice(0, 2), { t: log[2].t, jenis: log[2].jenis, ringkas: log[2].ringkas, data: log[2].data })[2].hash;
  const v = H.verifikasi(log); eq(v.ok, false); eq(v.di, 4);
});
uji('menghapus entri di tengah terdeteksi', () => {
  const log = klon(rantai(5)); log.splice(2, 1);
  eq(H.verifikasi(log).ok, false);
});
uji('segel berubah jika isi kartu atau kepala log berubah', () => {
  const a = H.segel({ total: 1163 }, 'abc'), b = H.segel({ total: 1164 }, 'abc'), c = H.segel({ total: 1163 }, 'abd');
  eq(a === b || a === c, false); eq(H.segelPendek(a).length, 9);
});

/* berkas uji tambahan dimuat berurutan; galat saat memuat dihitung sebagai kegagalan */
['store.test.js', 'render.test.js'].forEach((f) => {
  if (!require('fs').existsSync(path.join(__dirname, f))) return;
  try { require('./' + f)({ uji, eq, dekat, klon }); } catch (e) { gagal++; console.log('  ✗ ' + f + '\n      ' + e.stack); }
});

console.log('\n' + lulus + ' lulus, ' + gagal + ' gagal\n');
process.exit(gagal ? 1 : 0);
