/*
 * store.js — STATE aplikasi, AKSI yang mengubahnya, dan penyimpanan di browser.
 *
 * Pola: setiap aksi adalah fungsi murni  (s, p, now) => s  yang menerima SALINAN state.
 * Aksi yang mengubah data penting juga menambah satu entri ke log berantai (hash.js),
 * jadi riwayat perubahan ikut terekam. Aksi dengan p.sunyi = true (dipakai saat mengetik)
 * mengubah angka tanpa mencatat log; log ditulis sekali ketika kolom selesai diedit.
 *
 * Menambah aksi baru: tulis fungsinya di objek `aksi`, lalu panggil dari UI dengan
 *   JEJAK.store.act('namaAksi', { ... })
 */
(function (root) {
  'use strict';
  var J = (root.JEJAK = root.JEJAK || {});
  var D = J.data, C = J.calc, H = J.hash;
  var KUNCI = 'jejak-simulasi/v1';
  var JUMLAH_LANGKAH = 7;

  function klon(x) { return JSON.parse(JSON.stringify(x)); }
  function sekarang() { return new Date().toISOString(); }
  function bulat(x, d) { var k = Math.pow(10, d); return Math.round(x * k) / k; }

  /* ================= State awal dan catatan log ================= */

  function catat(s, now, jenis, ringkas, data) {
    s.log = H.tambah(s.log, { t: now, jenis: jenis, ringkas: ringkas, data: data || {} });
    return s;
  }

  function stateAwal(now) {
    var s = {
      v: 1,
      dv: D.versi,
      langkah: 1,
      dilihat: [1],
      usaha: D.kasus.nama,
      penjualan: D.kasus.penjualan,
      belanjaTotal: D.kasus.belanjaTotal,
      param: klon(D.param),
      pos: klon(D.pos),
      izin: {},   // diisi dari D.izin di bawah, jadi menambah izin cukup lewat data.js
      band: klon(D.band),
      sampel: {},
      bagi: {},
      log: [],
      rusak: null
    };
    D.izin.forEach(function (i) { s.izin[i.id] = false; });
    D.penerima.forEach(function (p) { s.bagi[p.id] = { aktif: false, bidang: p.bidang.slice(), sejak: null }; });
    return catat(s, now || sekarang(), 'mulai', 'Simulasi dimulai dengan kasus awal ' + D.kasus.nama, {});
  }

  /* ================= Pembacaan state ================= */

  /* Penjualan hanya dihitung jika pemilik mengizinkan pembacaan penjualan. */
  function masukan(s) {
    return { penjualan: s.izin.penjualan ? s.penjualan : 0, belanjaTotal: s.belanjaTotal, param: s.param, pos: s.pos };
  }

  function cariPos(s, id) { return s.pos.filter(function (p) { return p.id === id; })[0]; }
  function bawaan(id) { return D.pos.some(function (p) { return p.id === id; }); }

  /* Izin yang dibutuhkan tiap langkah: "semua" harus ada, "salahSatu" cukup satu. */
  var SYARAT = {
    1: { semua: [] },
    2: { salahSatu: ['penjualan', 'pembayaran'] },
    3: { semua: ['penjualan', 'pembayaran'] },
    4: { semua: ['pembayaran', 'estimasi'] },
    5: { semua: ['pembayaran', 'estimasi'] },
    6: { semua: ['pembayaran', 'estimasi'] },
    7: { semua: ['pembayaran', 'estimasi', 'bagikan'] }
  };

  function akses(s, n) {
    var sy = SYARAT[n], kurang;
    if (sy.salahSatu) kurang = sy.salahSatu.some(function (k) { return s.izin[k]; }) ? [] : sy.salahSatu.slice();
    else kurang = sy.semua.filter(function (k) { return !s.izin[k]; });
    return { ok: kurang.length === 0, kurang: kurang, salahSatu: !!sy.salahSatu };
  }

  /** Semua angka turunan yang dipakai banyak langkah, dihitung sekali per render. */
  function turunan(s) {
    var inp = masukan(s);
    var h = C.hitungSemua(inp);
    return { inp: inp, h: h, sens: C.sensitivitas(inp, s.band), lr: C.labaRugi(inp), ind: C.hitungUlangIndependen(inp) };
  }

  var _dasar = null;
  /** Hasil kasus awal, untuk membandingkan ("naik 301 kg dari kasus awal"). */
  function dasar() {
    if (!_dasar) _dasar = C.hitungSemua({ penjualan: D.kasus.penjualan, belanjaTotal: D.kasus.belanjaTotal, param: D.param, pos: D.pos });
    return _dasar;
  }

  function kepalaLog(s) { return s.log.length ? s.log[s.log.length - 1].hash : H.GENESIS; }

  /** Isi kartu yang disegel. Angka dibulatkan supaya segel stabil. */
  function kartuIsi(s, t) {
    var h = t.h, g = t.sens.gabungan;
    return {
      versi: 1,
      usaha: s.usaha,
      emisi: {
        totalKgBulan: bulat(h.totalKg, 1),
        rentangKgBulan: [Math.round(g.lo), Math.round(g.hi)],
        tahunTon: bulat(h.tahunTon, 2),
        intensitasKgPerRp1Juta: h.intensitas == null ? null : bulat(h.intensitas, 1)
      },
      cakupanDataPersen: bulat(h.cakupan * 100, 1),
      rincian: h.rows.map(function (r) {
        var p = cariPos(s, r.id) || {};
        return { pos: r.nama, kgBulan: bulat(r.kg, 1), porsiPersen: bulat(r.porsi * 100, 1), tingkat: r.tier, cakupan: p.cakupan || '', latihan: !!p.latihan };
      }),
      sampelDicocokkan: s.pos.filter(function (p) { return s.sampel[p.id]; }).map(function (p) { return p.nama; }),
      parameter: { kurs: s.param.kurs, tarif: s.param.tarif, faktorJaringan: s.param.jaringan },
      log: { jumlah: s.log.length, kepala: kepalaLog(s) }
    };
  }

  function segelKartu(s, t) { return H.segel(kartuIsi(s, t), kepalaLog(s)); }

  /** Paket data yang akan diterima satu pihak: hanya bidang yang dicentang. */
  function paketBagi(s, id, t) {
    var cfg = s.bagi[id], info = D.penerima.filter(function (p) { return p.id === id; })[0];
    var h = t.h, g = t.sens.gabungan, o = {};
    o.untuk = info.nama;
    o.tujuan = info.tujuan;
    o.dari = s.usaha;
    var ada = function (b) { return cfg.bidang.indexOf(b) >= 0; };
    if (ada('total')) o.total_kgco2e_per_bulan = bulat(h.totalKg, 1);
    if (ada('rentang')) o.rentang_kgco2e_per_bulan = [Math.round(g.lo), Math.round(g.hi)];
    if (ada('intensitas')) o.kgco2e_per_rp1_juta_penjualan = h.intensitas == null ? null : bulat(h.intensitas, 1);
    if (ada('cakupan')) o.cakupan_data_belanja_digital_persen = bulat(h.cakupan * 100, 1);
    if (ada('rincian')) o.rincian = h.rows.map(function (r) {
      var p = cariPos(s, r.id) || {};
      return { pos: r.nama, kgco2e_per_bulan: bulat(r.kg, 1), tingkat: r.tier, cakupan: p.cakupan || '' };
    });
    if (ada('penjualan')) o.penjualan_rp_per_bulan = s.penjualan;
    if (ada('laba')) o.selisih_penjualan_belanja_rp = t.lr.laba;
    o.segel = H.segelPendek(segelKartu(s, t));
    return o;
  }

  /* ================= Validasi masukan pengguna ================= */

  function slotKosong(s) {
    for (var i = 0; i < D.palet.length; i++) if (!s.pos.some(function (p) { return p.slot === i; })) return i;
    return -1;
  }

  function idBaru(s, nama) {
    var dasarId = String(nama).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || 'pos';
    var id = dasarId, n = 2;
    while (cariPos(s, id)) id = dasarId + '-' + n++;
    return id;
  }

  /** f = { nama, kat, rupiah, faktorPilih, faktorUSD, sumber }  → { ok, galat | pos } */
  function cekPosBaru(s, f) {
    var nama = String(f.nama || '').trim();
    if (s.pos.length >= D.maksPos) return { ok: false, galat: 'Maksimal ' + D.maksPos + ' pos. Hapus satu pos tambahan dulu.' };
    if (!nama) return { ok: false, galat: 'Isi nama pos.' };
    if (nama.length > 32) return { ok: false, galat: 'Nama pos maksimal 32 karakter.' };
    if (s.pos.some(function (p) { return p.nama.toLowerCase() === nama.toLowerCase(); })) return { ok: false, galat: 'Nama pos sudah dipakai.' };
    var rupiah = C.parseNum(f.rupiah);
    if (!(rupiah > 0)) return { ok: false, galat: 'Isi belanja per bulan dengan angka lebih dari 0.' };
    var slot = slotKosong(s);
    var pos = { id: idBaru(s, nama), nama: nama, kat: f.kat === 'listrik' ? 'listrik' : 'bahan', rupiah: rupiah, slot: slot };
    if (pos.kat === 'listrik') {
      pos.tier = 'T2'; pos.cakupan = 'Cakupan 2';
    } else {
      pos.tier = 'T1'; pos.cakupan = 'Cakupan 3 kat. 1';
      var pil = D.faktorPilihan.filter(function (x) { return x.id === f.faktorPilih; })[0];
      if (pil) { pos.faktorUSD = pil.nilai; pos.sumberFaktor = pil.sumber + ', ' + pil.label; }
      else {
        var fe = C.parseNum(f.faktorUSD), sumber = String(f.sumber || '').trim();
        if (!(fe > 0)) return { ok: false, galat: 'Isi faktor emisi (kgCO2e per USD) dengan angka lebih dari 0.' };
        if (sumber.length < 3) return { ok: false, galat: 'Isi sumber faktor emisi. Tanpa sumber, angka tidak bisa diperiksa.' };
        pos.faktorUSD = fe; pos.sumberFaktor = sumber;
      }
    }
    return { ok: true, pos: pos };
  }

  /** f = { id, tier, qty, unit, fq, sumber } → { ok, galat | data } */
  function cekNaikTangga(s, f) {
    var p = cariPos(s, f.id);
    if (!p || p.kat !== 'bahan') return { ok: false, galat: 'Hanya pos barang yang bisa naik tangga.' };
    var tier = f.tier === 'T3' ? 'T3' : 'T2';
    var qty = C.parseNum(f.qty), fq = C.parseNum(f.fq), unit = String(f.unit || 'kg').trim() || 'kg', sumber = String(f.sumber || '').trim();
    if (!(qty > 0)) return { ok: false, galat: 'Isi kuantitas per bulan dengan angka lebih dari 0.' };
    if (!(fq > 0)) return { ok: false, galat: 'Isi faktor per ' + unit + ' dengan angka lebih dari 0.' };
    if (sumber.length < 3) return { ok: false, galat: 'Isi sumber faktor. Tanpa sumber, angka tidak bisa diperiksa.' };
    return { ok: true, data: { id: p.id, tier: tier, qty: qty, unit: unit, fq: fq, sumber: sumber, latihan: !!f.latihan } };
  }

  /* ================= Aksi ================= */

  var NAMA_IZIN = {};
  D.izin.forEach(function (i) { NAMA_IZIN[i.id] = i; });

  function putusBagi(s, now, alasan) {
    D.penerima.forEach(function (pn) {
      var b = s.bagi[pn.id];
      if (b.aktif) {
        b.aktif = false; b.sejak = null;
        catat(s, now, 'bagi_cabut', 'Akses ' + pn.nama + ' dihentikan: ' + alasan, { penerima: pn.id });
      }
    });
  }

  var JALUR_ANGKA = {
    penjualan: { label: 'Penjualan per bulan', ambil: function (s) { return s.penjualan; }, taruh: function (s, v) { s.penjualan = v; }, rp: true },
    belanjaTotal: { label: 'Belanja operasional per bulan', ambil: function (s) { return s.belanjaTotal; }, taruh: function (s, v) { s.belanjaTotal = v; }, rp: true },
    kurs: { label: 'Kurs', ambil: function (s) { return s.param.kurs; }, taruh: function (s, v) { s.param.kurs = v; }, rp: true },
    tarif: { label: 'Tarif listrik', ambil: function (s) { return s.param.tarif; }, taruh: function (s, v) { s.param.tarif = v; } },
    jaringan: { label: 'Faktor listrik jaringan', ambil: function (s) { return s.param.jaringan; }, taruh: function (s, v) { s.param.jaringan = v; } }
  };

  function tampilNilai(j, v) { return j.rp ? C.fmtRp(v) : C.fmtRingkas(v, 4); }

  var BIDANG_POS = {
    rupiah: { label: 'belanja', rp: true }, qty: { label: 'kuantitas' }, fq: { label: 'faktor per satuan' }, faktorUSD: { label: 'faktor per USD' }
  };

  var aksi = {
    /* Navigasi (tidak dicatat di log) */
    ke: function (s, p) {
      var n = Math.max(1, Math.min(JUMLAH_LANGKAH, parseInt(p.n, 10) || 1));
      s.langkah = n;
      if (s.dilihat.indexOf(n) < 0) s.dilihat.push(n);
      return s;
    },

    /* Langkah 1: izin */
    izin: function (s, p, now) {
      var kunci = p.kunci, nilai = !!p.nilai;
      if (!(kunci in s.izin) || s.izin[kunci] === nilai) return s;
      s.izin[kunci] = nilai;
      var info = NAMA_IZIN[kunci];
      if (nilai) catat(s, now, 'izin_beri', 'Izin diberikan: ' + info.masuk, { izin: kunci });
      else catat(s, now, 'izin_cabut', 'Izin dicabut: ' + info.judul.toLowerCase(), { izin: kunci });
      if (!nilai && (kunci === 'bagikan' || kunci === 'pembayaran' || kunci === 'estimasi')) putusBagi(s, now, 'izin dicabut');
      if (!nilai && kunci === 'penjualan') {
        /* bidang yang bergantung pada penjualan tidak boleh tetap dibagikan */
        D.penerima.forEach(function (pn) {
          var b = s.bagi[pn.id], sisa = b.bidang.filter(function (id) {
            var bd = D.bidang.filter(function (x) { return x.id === id; })[0];
            return !(bd && bd.butuh === 'penjualan');
          });
          if (sisa.length !== b.bidang.length) {
            b.bidang = sisa;
            if (b.aktif) catat(s, now, 'bagi_ubah', 'Bidang untuk ' + pn.nama + ' dikurangi karena izin penjualan dicabut', { penerima: pn.id, bidang: sisa.slice() });
          }
        });
      }
      return s;
    },
    izinSemua: function (s, p, now) {
      D.izin.forEach(function (i) { if (!s.izin[i.id]) { s.izin[i.id] = true; catat(s, now, 'izin_beri', 'Izin diberikan: ' + i.masuk, { izin: i.id }); } });
      return s;
    },

    /* Data usaha */
    usaha: function (s, p, now) {
      var nama = String(p.nilai == null ? '' : p.nilai).slice(0, 40);
      var sebelum = p.sebelum !== undefined ? p.sebelum : s.usaha;
      s.usaha = nama;
      if (!p.sunyi && nama.trim() && nama !== sebelum) catat(s, now, 'usaha', 'Nama usaha diubah menjadi "' + nama + '"', { dari: sebelum, menjadi: nama });
      return s;
    },
    angka: function (s, p, now) {
      var j = JALUR_ANGKA[p.kunci];
      if (!j || !(p.nilai > 0) || !isFinite(p.nilai)) return s;
      var sebelum = p.sebelum !== undefined ? p.sebelum : j.ambil(s);
      j.taruh(s, p.nilai);
      if (!p.sunyi && sebelum !== p.nilai) catat(s, now, 'angka', j.label + ' diubah dari ' + tampilNilai(j, sebelum) + ' menjadi ' + tampilNilai(j, p.nilai), { kunci: p.kunci, dari: sebelum, menjadi: p.nilai });
      return s;
    },
    pos: function (s, p, now) {
      var x = cariPos(s, p.id), b = BIDANG_POS[p.bidang];
      if (!x || !b || !(p.nilai > 0) || !isFinite(p.nilai)) return s;
      var sebelum = p.sebelum !== undefined ? p.sebelum : x[p.bidang];
      x[p.bidang] = p.nilai;
      if (!p.sunyi && sebelum !== p.nilai) {
        var tampil = function (v) { return b.rp ? C.fmtRp(v) : C.fmtRingkas(v, 4); };
        catat(s, now, 'pos', x.nama + ': ' + b.label + ' diubah dari ' + tampil(sebelum) + ' menjadi ' + tampil(p.nilai), { pos: x.id, bidang: p.bidang, dari: sebelum, menjadi: p.nilai });
      }
      return s;
    },
    tambahPos: function (s, p, now) {
      var cek = cekPosBaru(s, p);
      if (!cek.ok) return s;
      s.pos.push(cek.pos);
      catat(s, now, 'pos_tambah', 'Pos baru: ' + cek.pos.nama + ' (' + C.fmtRp(cek.pos.rupiah) + ' per bulan, ' + cek.pos.tier + ')', { pos: cek.pos.id, rupiah: cek.pos.rupiah, tier: cek.pos.tier });
      return s;
    },
    hapusPos: function (s, p, now) {
      var x = cariPos(s, p.id);
      if (!x || bawaan(x.id)) return s;
      s.pos = s.pos.filter(function (q) { return q.id !== x.id; });
      delete s.sampel[x.id];
      catat(s, now, 'pos_hapus', 'Pos dihapus: ' + x.nama, { pos: x.id });
      return s;
    },

    /* Putaran perbaikan: naik atau turun tangga data */
    naikTangga: function (s, p, now) {
      var cek = cekNaikTangga(s, p);
      if (!cek.ok) return s;
      var d = cek.data, x = cariPos(s, d.id);
      x.tier = d.tier; x.qty = d.qty; x.unit = d.unit; x.fq = d.fq; x.sumberFq = d.sumber; x.latihan = d.latihan;
      catat(s, now, 'naik_tangga', 'Putaran perbaikan: ' + x.nama + ' naik dari T1 ke ' + d.tier + ' (' + C.fmtRingkas(d.qty, 2) + ' ' + d.unit + ' per bulan' + (d.latihan ? ', angka latihan' : '') + ')', { pos: x.id, tier: d.tier, qty: d.qty, fq: d.fq });
      return s;
    },
    turunTangga: function (s, p, now) {
      var x = cariPos(s, p.id);
      if (!x || x.kat !== 'bahan' || x.tier === 'T1' || !(x.faktorUSD > 0)) return s;
      var dari = x.tier;
      x.tier = 'T1'; delete x.qty; delete x.unit; delete x.fq; delete x.sumberFq; delete x.latihan;
      catat(s, now, 'turun_tangga', x.nama + ' dikembalikan dari ' + dari + ' ke T1', { pos: x.id });
      return s;
    },
    sampel: function (s, p, now) {
      var x = cariPos(s, p.id), nilai = !!p.nilai;
      if (!x || !!s.sampel[x.id] === nilai) return s;
      if (nilai) s.sampel[x.id] = true; else delete s.sampel[x.id];
      catat(s, now, 'sampel', x.nama + (nilai ? ' dicocokkan dengan nota (sampel, simulasi)' : ': tanda cocok nota dilepas'), { pos: x.id, cocok: nilai });
      return s;
    },
    band: function (s, p, now) {
      var kunci = p.kunci, idx = p.idx, v = p.nilai;
      if (!(v > 0) || !isFinite(v)) return s;
      var sebelum;
      if (idx === undefined || idx === null) { sebelum = s.band[kunci]; s.band[kunci] = v; }
      else { sebelum = s.band[kunci][idx]; s.band[kunci][idx] = v; }
      if (s.band.c3[0] > s.band.c3[1]) s.band.c3 = [s.band.c3[1], s.band.c3[0]];
      if (s.band.t2[0] > s.band.t2[1]) s.band.t2 = [s.band.t2[1], s.band.t2[0]];
      if (s.band.t3[0] > s.band.t3[1]) s.band.t3 = [s.band.t3[1], s.band.t3[0]];
      if (!p.sunyi && sebelum !== v) catat(s, now, 'band', 'Rentang sensitivitas ' + kunci + ' diubah dari ' + C.fmtRingkas(sebelum, 3) + ' menjadi ' + C.fmtRingkas(v, 3), { kunci: kunci, idx: idx === undefined ? null : idx, dari: sebelum, menjadi: v });
      return s;
    },

    /* Langkah 7: pembagian selektif */
    bagi: function (s, p, now) {
      var b = s.bagi[p.id], info = D.penerima.filter(function (x) { return x.id === p.id; })[0];
      if (!b || !info) return s;
      var aktif = !!p.aktif;
      if (aktif === b.aktif) return s;
      if (aktif) {
        if (!(s.izin.bagikan && s.izin.pembayaran && s.izin.estimasi)) return s;
        if (!b.bidang.length) return s;
        b.aktif = true; b.sejak = now;
        catat(s, now, 'bagi_beri', 'Kartu dibagikan ke ' + info.nama + ' (' + b.bidang.length + ' bidang)', { penerima: p.id, bidang: b.bidang.slice() });
      } else {
        b.aktif = false; b.sejak = null;
        catat(s, now, 'bagi_cabut', 'Akses ' + info.nama + ' dicabut oleh pemilik usaha', { penerima: p.id });
      }
      return s;
    },
    bagiBidang: function (s, p, now) {
      var b = s.bagi[p.id], info = D.penerima.filter(function (x) { return x.id === p.id; })[0];
      var bd = D.bidang.filter(function (x) { return x.id === p.bidang; })[0];
      if (!b || !info || !bd) return s;
      var ada = b.bidang.indexOf(p.bidang) >= 0, nilai = !!p.nilai;
      if (ada === nilai) return s;
      if (nilai && bd.butuh && !s.izin[bd.butuh]) return s;
      if (nilai) b.bidang.push(p.bidang); else b.bidang = b.bidang.filter(function (x) { return x !== p.bidang; });
      var urut = D.bidang.map(function (x) { return x.id; });
      b.bidang.sort(function (x, y) { return urut.indexOf(x) - urut.indexOf(y); });
      if (b.aktif) {
        catat(s, now, 'bagi_ubah', 'Bidang untuk ' + info.nama + ' diubah (' + b.bidang.length + ' bidang)', { penerima: p.id, bidang: b.bidang.slice() });
        if (!b.bidang.length) { b.aktif = false; b.sejak = null; catat(s, now, 'bagi_cabut', 'Akses ' + info.nama + ' berhenti karena tidak ada bidang yang dibagikan', { penerima: p.id }); }
      }
      return s;
    },

    /* Langkah 5: demonstrasi manipulasi log */
    rusak: function (s, p) {
      var e = s.log[(parseInt(p.i, 10) || 0) - 1];
      if (!e || s.rusak) return s;
      s.rusak = { i: e.i, asli: { ringkas: e.ringkas } };
      e.ringkas = e.ringkas + ' (diubah diam-diam)';
      return s;
    },
    pulihkan: function (s) {
      if (!s.rusak) return s;
      var e = s.log[s.rusak.i - 1];
      if (e) e.ringkas = s.rusak.asli.ringkas;
      s.rusak = null;
      return s;
    },

    reset: function (s, p, now) { return stateAwal(now); }
  };

  /** Terapkan satu aksi pada salinan state (murni; dipakai pengujian dan act). */
  function terapkan(s, nama, p, now) {
    if (!aksi[nama]) throw new Error('Aksi tidak dikenal: ' + nama);
    return aksi[nama](klon(s), p || {}, now || sekarang());
  }

  /* ================= Penyimpanan di browser ================= */

  function sah(s) {
    return s && s.v === 1 && s.dv === D.versi && Array.isArray(s.pos) && Array.isArray(s.log) && s.izin && s.param && s.bagi && s.band &&
      s.pos.every(function (p) { return p && typeof p.id === 'string' && p.rupiah > 0; });
  }

  function muat() {
    try {
      var mentah = root.localStorage && root.localStorage.getItem(KUNCI);
      if (!mentah) return null;
      var s = JSON.parse(mentah);
      return sah(s) ? s : null;
    } catch (e) { return null; }
  }
  function simpan(s) { try { root.localStorage && root.localStorage.setItem(KUNCI, JSON.stringify(s)); } catch (e) { /* mode privat: abaikan */ } }

  var state = null, pendengar = [];
  function mulai() { state = muat() || stateAwal(sekarang()); return state; }
  function ambil() { return state; }
  function act(nama, p) {
    var baru = terapkan(state, nama, p, sekarang());
    state = baru;
    simpan(state);
    pendengar.forEach(function (f) { f(state); });
    return state;
  }
  function langganan(f) { pendengar.push(f); }

  J.store = {
    KUNCI: KUNCI, JUMLAH_LANGKAH: JUMLAH_LANGKAH, SYARAT: SYARAT,
    stateAwal: stateAwal, aksi: aksi, terapkan: terapkan,
    masukan: masukan, cariPos: cariPos, bawaan: bawaan, akses: akses, turunan: turunan, dasar: dasar,
    kepalaLog: kepalaLog, kartuIsi: kartuIsi, segelKartu: segelKartu, paketBagi: paketBagi,
    cekPosBaru: cekPosBaru, cekNaikTangga: cekNaikTangga,
    mulai: mulai, ambil: ambil, act: act, langganan: langganan
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = J.store;
})(typeof window !== 'undefined' ? window : globalThis);
