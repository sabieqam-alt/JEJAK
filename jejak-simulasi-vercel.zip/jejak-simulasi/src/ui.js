/*
 * ui.js — potongan HTML kecil yang dipakai berulang, plus morph().
 *
 * Semua tampilan di aplikasi ini adalah fungsi (state) → teks HTML. Setelah tiap perubahan,
 * morph() menyamakan DOM yang ada dengan HTML baru TANPA mengganti elemen yang sama.
 * Akibatnya kolom yang sedang diketik tidak kehilangan fokus dan posisi kursor.
 *
 * Aturan menulis tampilan:
 *   - teks dari pengguna WAJIB lewat esc(); teks dari data.js boleh berisi HTML sederhana.
 *   - kolom yang nilainya mengikuti state diberi atribut value="...";
 *     kolom isian bebas (formulir) tanpa atribut value supaya ketikan tidak tertimpa.
 */
(function (root) {
  'use strict';
  var J = (root.JEJAK = root.JEJAK || {});
  var D = J.data, C = J.calc;

  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(x) { return String(x == null ? '' : x).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }

  var CO2E = 'CO<sub>2</sub>e';
  var KG = 'kg' + CO2E;

  function warna(slot) { return D.palet[slot % D.palet.length]; }

  /* ---------- ikon (garis 1.8px, 24×24) ---------- */
  var IKON = {
    cek: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    kunci: '<rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    tambah: '<path d="M12 5v14M5 12h14"/>',
    hapus: '<path d="M6 6l12 12M18 6L6 18"/>',
    cetak: '<path d="M7 9V4h10v5"/><path d="M7 17H5a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2"/><rect x="7" y="14" width="10" height="6"/>',
    unduh: '<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 19h14"/>',
    ulang: '<path d="M4 12a8 8 0 1 0 2.6-5.9"/><path d="M4 4v4.5h4.5"/>',
    awas: '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.2v.1"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8v.1"/>'
  };
  function ikon(nama, ukuran) {
    var u = ukuran || 18;
    return '<svg class="ikon" width="' + u + '" height="' + u + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + IKON[nama] + '</svg>';
  }

  /* ---------- logo daun ---------- */
  function daun(u) {
    return '<svg class="daun" width="' + u + '" height="' + u + '" viewBox="0 0 100 100" aria-hidden="true" focusable="false"><path d="M14 86C10 44 36 14 86 12c4 46-24 76-72 74z" fill="#12805f"/><path d="M18 82C40 60 58 42 78 22" stroke="#fbf4de" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M40 62l-1-14M54 48l10-3" stroke="#fbf4de" stroke-width="3" fill="none" stroke-linecap="round"/></svg>';
  }

  /* ---------- label tingkat data ---------- */
  function tingkat(t, latihan) {
    return '<span class="tingkat ' + t.toLowerCase() + '" title="' + esc(D.tingkat[t].judul + ': ' + D.tingkat[t].mutu) + '">' + t + '</span>' + (latihan ? '<span class="latihan" title="Angka latihan, bukan data nyata">latihan</span>' : '');
  }

  /* ---------- kolom angka bergaya form kertas ----------
   * o: kunci (unik, dipakai untuk fokus), masuk (nama penangan di app.js), nilai (teks tampilan),
   *    label (HTML tepercaya), awalan, akhiran, data {kunci:nilai}, galat, bantu, kecil */
  function inputAngka(o) {
    var id = 'f-' + String(o.kunci).replace(/[^a-z0-9]/gi, '-');
    var data = Object.keys(o.data || {}).map(function (k) { return ' data-' + k + '="' + esc(o.data[k]) + '"'; }).join('');
    return '<div class="isi' + (o.galat ? ' salah' : '') + (o.kecil ? ' kecil' : '') + '">' +
      '<label for="' + id + '">' + o.label + '</label>' +
      '<span class="kolom">' + (o.awalan ? '<span class="aw">' + o.awalan + '</span>' : '') +
      '<input id="' + id + '" class="angka" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" data-key="' + esc(o.kunci) + '" data-in="' + o.masuk + '" data-ch="' + o.masuk + '"' + data + ' value="' + esc(o.nilai) + '"' + (o.galat ? ' aria-invalid="true" aria-describedby="' + id + '-g"' : (o.bantu ? ' aria-describedby="' + id + '-b"' : '')) + '>' +
      (o.akhiran ? '<span class="ak">' + o.akhiran + '</span>' : '') + '</span>' +
      (o.galat ? '<span class="galat" id="' + id + '-g" role="alert">' + esc(o.galat) + '</span>' : '') +
      (o.bantu ? '<span class="bantu" id="' + id + '-b">' + o.bantu + '</span>' : '') + '</div>';
  }

  /* ---------- waktu ---------- */
  var BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  function dua(n) { return (n < 10 ? '0' : '') + n; }
  function waktu(iso) { var d = new Date(iso); return isNaN(d) ? '–' : dua(d.getHours()) + ':' + dua(d.getMinutes()) + ':' + dua(d.getSeconds()); }
  function tanggal(iso) { var d = new Date(iso); return isNaN(d) ? '–' : d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear(); }

  /* ---------- cap/segel (satu-satunya hiasan; berubah merah jika rantai log putus) ----------
   * Teks atas mengikuti busur atas, teks bawah busur bawah; keduanya diratakan ke tengah
   * (text-anchor middle), jadi tidak bergantung pada lebar font. */
  function cap(kode, ok, id) {
    var a = kode.slice(0, 4), b = kode.slice(5, 9);
    var atas = ok ? 'SEGEL LOG AUDIT' : 'RANTAI LOG', bawah = ok ? 'JEJAK' : 'PUTUS';
    var lingkar = function (arah, teks) {
      return '<text class="cap-lingkar" text-anchor="middle" fill="currentColor" stroke="none"><textPath href="#cap-' + arah + '-' + id + '" startOffset="50%">' + teks + '</textPath></text>';
    };
    return '<svg class="cap ' + (ok ? 'ok' : 'putus') + '" viewBox="0 0 140 140" role="img" aria-label="' + (ok ? 'Segel ' + kode + ', rantai log utuh' : 'Segel tidak berlaku, rantai log putus') + '">' +
      '<defs><path id="cap-a-' + id + '" d="M25 70A45 45 0 0 1 115 70"/><path id="cap-b-' + id + '" d="M18 70A52 52 0 0 0 122 70"/>' +
      '<filter id="cap-t-' + id + '" x="-6%" y="-6%" width="112%" height="112%"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.4"/></filter></defs>' +
      '<g filter="url(#cap-t-' + id + ')" fill="none" stroke="currentColor">' +
      '<circle cx="70" cy="70" r="65" stroke-width="3.6"/><circle cx="70" cy="70" r="58.5" stroke-width="1.1"/><circle cx="70" cy="70" r="34" stroke-width="1.4"/>' +
      lingkar('a', atas) + lingkar('b', bawah) +
      '<circle cx="21.5" cy="70" r="2" fill="currentColor" stroke="none"/><circle cx="118.5" cy="70" r="2" fill="currentColor" stroke="none"/>' +
      '<text class="cap-kode" x="70" y="67" text-anchor="middle" fill="currentColor" stroke="none">' + a + '</text>' +
      '<text class="cap-kode" x="70" y="86" text-anchor="middle" fill="currentColor" stroke="none">' + b + '</text>' +
      (ok ? '' : '<path d="M30 112L110 28" stroke-width="5"/>') +
      '</g></svg>';
  }

  /* ---------- kepala langkah, navigasi, panel terkunci ---------- */
  function kepala(l, lead) {
    return '<header class="kepala"><p class="posisi">' + l.fase + ', langkah ' + l.n + ' dari 7</p>' +
      '<div class="judul-baris"><span class="no" aria-hidden="true">' + l.n + '</span><h1 id="judul-langkah" tabindex="-1">' + l.judul + '</h1></div>' +
      '<p class="lead">' + lead + '</p></header>';
  }

  function terkunci(c, n) {
    var ak = c.ak, S = J.store;
    var butuh = ak.kurang.map(function (k) { return D.izin.filter(function (i) { return i.id === k; })[0]; });
    var nama = butuh.map(function (i) { return i.pendek; }).join(ak.salahSatu ? ' atau ' : ' dan ');
    return '<section class="terkunci" role="status">' + ikon('kunci', 30) +
      '<div><h2>Langkah ini terkunci</h2>' +
      '<p>Tanpa izin, data tidak mengalir. ' + (ak.salahSatu ? 'Beri izin untuk salah satu: ' : 'Izin yang dibutuhkan: ') + '<b>' + nama + '</b>.</p>' +
      '<div class="aksi-baris">' + butuh.map(function (i) {
        return '<button type="button" class="tombol utama" data-act="izin" data-kunci="' + i.id + '">Beri izin ' + i.pendek + '</button>';
      }).join('') + '<a class="tombol sekunder" href="#/1">Buka langkah 1</a></div></div></section>';
  }

  function nav(c, n) {
    var L = J.langkah, S = J.store, s = c.s;
    var h = '<nav class="nav-langkah" aria-label="Pindah langkah">';
    h += n > 1 ? '<a class="tombol sekunder" href="#/' + (n - 1) + '">Kembali ke langkah ' + (n - 1) + ': ' + L[n - 1].judul + '</a>' : '<span></span>';
    if (n < S.JUMLAH_LANGKAH) {
      var ak = S.akses(s, n + 1), label = 'Lanjut ke langkah ' + (n + 1) + ': ' + L[n + 1].judul;
      if (ak.ok) h += '<a class="tombol utama" href="#/' + (n + 1) + '">' + label + '</a>';
      else {
        var nama = ak.kurang.map(function (k) { return D.izin.filter(function (i) { return i.id === k; })[0].pendek; }).join(ak.salahSatu ? ' atau ' : ' dan ');
        h += '<span class="tertahan"><button type="button" class="tombol utama" disabled>' + label + '</button><span class="petunjuk">Butuh izin: ' + nama + '.</span></span>';
      }
    }
    return h + '</nav>';
  }

  /** Pengganti bagian layar yang datanya belum diizinkan. */
  function izinKurang(kunci) {
    var i = D.izin.filter(function (x) { return x.id === kunci; })[0];
    return '<div class="izin-kurang">' + ikon('kunci', 22) + '<p>Izin <b>' + i.pendek + '</b> belum diberikan, jadi bagian ini tidak terbaca.</p>' +
      '<button type="button" class="tombol sekunder" data-act="izin" data-kunci="' + kunci + '">Beri izin</button></div>';
  }

  /* ---------- morph: samakan DOM yang ada dengan HTML baru ---------- */
  function samakanAtribut(x, y) {
    var i, at;
    for (i = x.attributes.length - 1; i >= 0; i--) { at = x.attributes[i]; if (!y.hasAttribute(at.name)) x.removeAttribute(at.name); }
    for (i = 0; i < y.attributes.length; i++) { at = y.attributes[i]; if (x.getAttribute(at.name) !== at.value) x.setAttribute(at.name, at.value); }
    var nm = x.nodeName;
    if (nm === 'INPUT') {
      if (x.type === 'checkbox' || x.type === 'radio') x.checked = y.hasAttribute('checked');
      else if (y.hasAttribute('value') && x !== document.activeElement && x.value !== y.getAttribute('value')) x.value = y.getAttribute('value');
    } else if (nm === 'OPTION') {
      x.selected = y.hasAttribute('selected');
    }
  }
  function samakanAnak(a, b) {
    var lama = Array.prototype.slice.call(a.childNodes), tujuan = Array.prototype.slice.call(b.childNodes);
    var n = Math.max(lama.length, tujuan.length);
    for (var i = 0; i < n; i++) {
      var x = lama[i], y = tujuan[i];
      if (!y) { a.removeChild(x); continue; }
      if (!x) { a.appendChild(y); continue; }
      if (x.nodeType !== y.nodeType || x.nodeName !== y.nodeName) { a.replaceChild(y, x); continue; }
      if (x.nodeType !== 1) { if (x.nodeValue !== y.nodeValue) x.nodeValue = y.nodeValue; continue; }
      samakanAtribut(x, y);
      if (x.nodeName !== 'INPUT') samakanAnak(x, y);
    }
  }
  function morph(akar, html) {
    var baru = akar.cloneNode(false);
    baru.innerHTML = html;
    samakanAnak(akar, baru);
  }

  J.ui = {
    esc: esc, CO2E: CO2E, KG: KG, warna: warna, ikon: ikon, daun: daun, tingkat: tingkat, inputAngka: inputAngka,
    waktu: waktu, tanggal: tanggal, cap: cap, kepala: kepala, terkunci: terkunci, izinKurang: izinKurang, nav: nav, morph: morph
  };
  J.langkah = J.langkah || {};
})(typeof window !== 'undefined' ? window : globalThis);
