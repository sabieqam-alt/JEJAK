/*
 * data.js — KASUS, PARAMETER, SUMBER, dan TEKS PILIHAN.
 *
 * Ini satu-satunya file yang perlu Anda sunting untuk:
 *   - mengganti angka kasus (penjualan, belanja, nilai tiap pos),
 *   - mengganti kurs, tarif listrik, atau faktor emisi,
 *   - mengubah rentang sensitivitas,
 *   - mengubah daftar izin dan bidang yang bisa dibagikan.
 *
 * Aturan: teks di file ini boleh berisi HTML sederhana (<sub>, <b>) karena ditulis
 * oleh pengembang. Teks yang diketik pengguna di aplikasi selalu di-escape.
 * Semua angka rupiah dalam satuan per bulan.
 */
(function (root) {
  'use strict';
  var J = (root.JEJAK = root.JEJAK || {});

  J.data = {
    versi: 1,

    /* ---------- Kasus awal: warung makan hipotetis (Modul 4) ---------- */
    kasus: {
      nama: 'Warung Makan Hipotetis',
      penjualan: 25000000,      // Rp/bulan, sekitar 70% lewat QRIS
      belanjaTotal: 15000000    // belanja operasional Rp/bulan, digital + tunai
    },

    /* ---------- Parameter hitung (Modul 4, tabel parameter) ---------- */
    param: { kurs: 18100, tarif: 1444.7, jaringan: 0.87 },
    paramInfo: {
      kurs:     { label: 'Kurs', satuan: 'Rp per USD', sumber: 'Kisaran JISDOR Oktober 2026 (BI, 2026b)' },
      tarif:    { label: 'Tarif listrik', satuan: 'Rp per kWh', sumber: 'JournalArta (2026)' },
      jaringan: { label: 'Faktor listrik Jawa–Madura–Bali', satuan: 'kgCO<sub>2</sub> per kWh', sumber: 'GEC (2022), JCM FY2022' }
    },

    /*
     * Pos belanja yang terekam digital.
     *   kat   : 'listrik' (rupiah → kWh → kgCO2e, selalu T2)  atau  'bahan' (belanja barang)
     *   tier  : 'T1' belanja × faktor per USD | 'T2' kuantitas × faktor per satuan | 'T3' faktor khusus pemasok
     *   slot  : nomor warna di `palet` (warna mengikuti pos, bukan urutan)
     */
    pos: [
      { id: 'listrik', nama: 'Listrik (token PLN)', kat: 'listrik', rupiah: 1500000, tier: 'T2', slot: 0,
        cakupan: 'Cakupan 2' },
      { id: 'ayam', nama: 'Ayam', kat: 'bahan', rupiah: 6000000, tier: 'T1', slot: 1,
        faktorUSD: 0.391, sumberFaktor: 'U.S. EPA (2024), Supply Chain GHG Emission Factors v1.3, pengolahan unggas',
        cakupan: 'Cakupan 3 kat. 1' },
      { id: 'beras', nama: 'Beras', kat: 'bahan', rupiah: 3000000, tier: 'T1', slot: 2,
        faktorUSD: 0.785, sumberFaktor: 'CSDI (2025), v1.4.0, penggilingan padi',
        cakupan: 'Cakupan 3 kat. 1' }
    ],
    maksPos: 5,

    /* Pilihan faktor T1 untuk pos baru. "Lainnya" meminta pengguna mengisi nilai dan sumbernya sendiri. */
    faktorPilihan: [
      { id: 'unggas', label: 'Pengolahan unggas', nilai: 0.391, sumber: 'U.S. EPA (2024), v1.3' },
      { id: 'padi',   label: 'Penggilingan padi', nilai: 0.785, sumber: 'CSDI (2025), v1.4.0' }
    ],

    /*
     * Isian cepat untuk mencoba "naik tangga" tanpa data nyata.
     * Sengaja bulat dan jelas palsu supaya tidak dikira faktor resmi; pos yang memakainya
     * diberi tanda "latihan" di tape, Kartu, dan log.
     */
    latihan: { qty: 150, unit: 'kg', fq: 1, sumber: 'Angka latihan, bukan faktor resmi' },

    /* Skenario "token listrik naik" dari latihan Modul 4 (tombol di langkah 4). */
    skenarioListrik: 2000000,

    /* Warna kategori, urutan tetap (sudah diperiksa dengan validate_palette.js untuk permukaan #fdfdf6). */
    palet: ['#12805f', '#b8452a', '#d9a228', '#2f6db5', '#c2457f'],

    /*
     * Rentang sensitivitas (Modul 5).
     *   c3      : pengali faktor emisi Cakupan 3 (barang, berbasis belanja)  — dari esai
     *   tarif, jaringan, kurs : ± persen
     *   t2, t3  : pengali ILUSTRASI untuk pos yang naik tangga (bukan hasil pengukuran)
     */
    band: { c3: [0.5, 2], tarif: 10, jaringan: 10, kurs: 5, t2: [0.8, 1.25], t3: [0.9, 1.1] },

    /* ---------- Tangga kualitas data (Modul 3) ---------- */
    tingkat: {
      T1: { nama: 'T1', judul: 'Berbasis belanja', isi: 'Belanja (rupiah) dikonversi ke dolar × faktor emisi per dolar.', mutu: 'Paling kasar' },
      T2: { nama: 'T2', judul: 'Kuantitas fisik', isi: 'Kuantitas fisik (kWh, kg) × faktor per satuan.', mutu: 'Lebih akurat' },
      T3: { nama: 'T3', judul: 'Data pemasok', isi: 'Faktor emisi khusus dari pemasok.', mutu: 'Paling akurat' }
    },

    /* ---------- Izin (Langkah 1) ---------- */
    izin: [
      { id: 'penjualan',  judul: 'Baca laporan penjualan QRIS', pendek: 'baca penjualan QRIS',
        isi: 'Laporan settlement dari PJP atau bank pengakuisisi. Yang dibaca hanya total penjualan per bulan.',
        dipakai: 'Langkah 2 dan 3',
        masuk: 'Laporan settlement QRIS dibaca' },
      { id: 'pembayaran', judul: 'Baca pembayaran keluar', pendek: 'baca pembayaran keluar',
        isi: 'Token listrik, pindai QRIS pemasok, transfer, dan foto nota. Belanja tunai yang tidak terbaca tetap di luar jangkauan.',
        dipakai: 'Langkah 2 sampai 7',
        masuk: 'Pembayaran keluar dibaca' },
      { id: 'estimasi',   judul: 'Hitung estimasi emisi dari data itu', pendek: 'hitung estimasi emisi',
        isi: 'Mengubah rupiah menjadi kgCO<sub>2</sub>e dan memberi label T1, T2, atau T3 pada setiap baris.',
        dipakai: 'Langkah 4 sampai 7',
        masuk: 'Estimasi emisi diizinkan' },
      { id: 'bagikan',    judul: 'Boleh dibagikan, hanya ke pihak yang saya pilih', pendek: 'bagikan selektif',
        isi: 'Bank atau pembeli korporat, bidang demi bidang. Izin ini bisa dicabut kapan saja dan akses langsung berhenti.',
        dipakai: 'Langkah 7',
        masuk: 'Pembagian selektif diizinkan' }
    ],

    /* ---------- Pembagian selektif (Langkah 7) ---------- */
    /* butuh: izin yang harus ada supaya bidang itu bisa dibagikan */
    bidang: [
      { id: 'total',      label: 'Total emisi per bulan' },
      { id: 'rentang',    label: 'Rentang ketidakpastian' },
      { id: 'intensitas', label: 'Emisi per Rp1 juta penjualan', butuh: 'penjualan' },
      { id: 'cakupan',    label: 'Cakupan data belanja digital' },
      { id: 'rincian',    label: 'Rincian per pos dengan label T1/T2/T3' },
      { id: 'penjualan',  label: 'Penjualan per bulan (rupiah)', butuh: 'penjualan' },
      { id: 'laba',       label: 'Selisih penjualan dan belanja (rupiah)', butuh: 'penjualan' }
    ],
    penerima: [
      { id: 'bank',   nama: 'Bank', tujuan: 'emisi dibiayai',
        bidang: ['total', 'rentang', 'intensitas', 'cakupan'] },
      { id: 'pembeli', nama: 'Pembeli korporat', tujuan: 'Cakupan 3 kategori 1',
        bidang: ['total', 'rentang', 'intensitas', 'cakupan', 'rincian'] }
    ],

    /* ---------- Sumber (ditampilkan di Kartu dan README) ---------- */
    catatanJujur: 'Faktor ayam dan beras berasal dari model input-output Amerika Serikat. Harga barang di Indonesia umumnya lebih rendah, jadi konversi dengan kurs pasar kemungkinan meremehkan emisi. Angka T1 adalah titik awal berlabel, bukan hasil pengukuran.',
    disclaimer: 'Simulasi hipotetis untuk menunjukkan orde besaran dan logika metode. Bukan data nyata warung, bukan estimasi nasional, dan bukan audit atau sertifikasi.'
  };
})(typeof window !== 'undefined' ? window : globalThis);
