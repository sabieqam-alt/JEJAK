/*
 * Langkah 5: Jaminan data (tiga lapis, Modul 3).
 *   1. Log audit berantai + hitung ulang independen (bisa dicoba langsung)
 *   2. Verifikasi sampel oleh akuntan pendamping atau koperasi (di sini hanya tanda simulasi)
 *   3. Asurans terbatas atas metodologi platform (keterangan, di luar aplikasi)
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, C = J.calc, U = J.ui, S = J.store, H = J.hash;
  var F = C.fmtNum, KG = U.KG;

  function potong(t, n) { return t.length > n ? t.slice(0, n - 1) + '…' : t; }

  function lapisLog(c) {
    var s = c.s, t = c.t, ui = c.ui, v = H.verifikasi(s.log);
    var h = '<section class="blok"><h2>Lapis 1: log audit yang tidak bisa diubah diam-diam</h2>' +
      '<p class="isi-teks">Setiap kejadian (izin, perubahan angka, naik tangga, pembagian) dicatat bersama sidik jari SHA-256 dari isinya dan sidik jari entri sebelumnya. Mengubah satu entri memutus rantai di entri itu.</p>' +
      '<div class="status-rantai ' + (v.ok ? 'ok' : 'putus') + '" role="status">' + U.cap(H.segelPendek(S.segelKartu(s, t)), v.ok, 'langkah5') +
      '<div><b>' + (v.ok ? 'Rantai utuh' : 'Rantai putus di entri ' + v.di) + '</b><p>' +
      (v.ok ? v.jumlah + ' entri diperiksa dari awal. Kepala rantai: <code>' + v.kepala.slice(0, 12) + '</code>.' : U.esc(v.alasan.charAt(0).toUpperCase() + v.alasan.slice(1)) + '. Entri sesudahnya tidak bisa dipercaya.') + '</p>' +
      (ui.diperiksa ? '<p class="meta">Terakhir diperiksa pukul ' + U.waktu(ui.diperiksa) + '.</p>' : '') + '</div></div>';

    h += '<div class="aksi-baris"><button type="button" class="tombol sekunder" data-act="periksa">Periksa rantai sekarang</button></div>';

    if (s.rusak) {
      h += '<div class="coba rusak-aktif"><p class="catatan awas">' + U.ikon('awas') + '<span>Entri ' + s.rusak.i + ' sudah diubah tanpa menghitung ulang sidik jarinya. Begitulah cara pemeriksaan menangkap pemalsuan.</span></p>' +
        '<button type="button" class="tombol sekunder" data-act="pulihkan">Pulihkan entri ' + s.rusak.i + '</button></div>';
    } else {
      var pilih = Math.min(ui.rusakPilih, s.log.length);
      h += '<div class="coba"><div class="isi lebar"><label for="pilih-rusak">Coba memalsukan satu entri</label><span class="kolom"><select id="pilih-rusak" data-ch="pilihRusak">' +
        s.log.map(function (e) { return '<option value="' + e.i + '"' + (e.i === pilih ? ' selected' : '') + '>#' + e.i + ' ' + U.esc(potong(e.ringkas, 56)) + '</option>'; }).join('') +
        '</select></span></div><button type="button" class="tombol sekunder" data-act="rusak">Ubah diam-diam</button></div>';
    }

    h += '<div class="gulir log-gulir"><table class="buku log"><thead><tr><th scope="col" class="angka">No</th><th scope="col">Waktu</th><th scope="col">Kejadian</th><th scope="col">Sidik jari</th></tr></thead><tbody>';
    s.log.slice().reverse().forEach(function (e) {
      var salah = !v.ok && v.di === e.i;
      h += '<tr' + (salah ? ' class="rusak"' : '') + '><td class="angka">' + e.i + '</td><td class="angka">' + U.waktu(e.t) + '</td><td>' + U.esc(e.ringkas) + (salah ? ' <span class="tanda-rusak">tidak cocok</span>' : '') + '</td><td><code>' + e.hash.slice(0, 8) + '</code></td></tr>';
    });
    return h + '</tbody></table></div></section>';
  }

  function hitungUlang(c) {
    var t = c.t, ind = t.ind, selisih = Math.abs(ind.total - t.h.totalKg), cocok = selisih < 1e-6;
    var h = '<section class="blok"><h2>Hitung ulang oleh pemeriksa independen</h2>' +
      '<p class="isi-teks">Pemeriksa menghitung ulang dari data mentah lewat jalur rumus yang terpisah dari tampilan. Jika angkanya berbeda, ada yang salah di salah satu jalur.</p>' +
      '<div class="gulir"><table class="buku"><thead><tr><th scope="col">Pos</th><th scope="col" class="angka">Aplikasi, ' + KG + '</th><th scope="col" class="angka">Pemeriksa, ' + KG + '</th><th scope="col" class="angka">Selisih</th></tr></thead><tbody>';
    t.h.rows.forEach(function (r, i) {
      h += '<tr><th scope="row"><span class="warna" style="--w:' + U.warna(r.slot) + '" aria-hidden="true"></span>' + U.esc(r.nama) + '</th><td class="angka">' + F(r.kg, 1) + '</td><td class="angka">' + F(ind.rows[i].kg, 1) + '</td><td class="angka">' + F(r.kg - ind.rows[i].kg, 3) + '</td></tr>';
    });
    h += '</tbody><tfoot><tr class="total"><th scope="row">Total</th><td class="angka">' + F(t.h.totalKg, 1) + '</td><td class="angka">' + F(ind.total, 1) + '</td><td class="angka">' + F(t.h.totalKg - ind.total, 3) + '</td></tr></tfoot></table></div>' +
      '<p class="catatan ' + (cocok ? 'ok' : 'awas') + '">' + U.ikon(cocok ? 'cek' : 'awas') + '<span>' + (cocok ? 'Cocok. Selisih total kurang dari 0,000001 ' + KG + '.' : 'Tidak cocok. Periksa rumus dan data mentah.') + '</span></p></section>';
    return h;
  }

  function lapisSampel(c) {
    var s = c.s, jml = s.pos.filter(function (p) { return s.sampel[p.id]; }).length;
    var h = '<section class="blok"><h2>Lapis 2: verifikasi sampel</h2>' +
      '<p class="isi-teks">Akuntan pendamping atau koperasi mencocokkan sampel pos dengan nota di lapangan. Pemeriksaan itu terjadi di luar aplikasi; tanda di bawah hanya simulasi dan akan muncul di Kartu.</p><ul class="daftar-sampel">';
    s.pos.forEach(function (p) {
      h += '<li><label class="sakelar kecil"><input type="checkbox" role="switch" data-ch="sampel" data-id="' + U.esc(p.id) + '"' + (s.sampel[p.id] ? ' checked' : '') + '><span class="geser" aria-hidden="true"></span>' +
        '<span class="teks"><b>' + U.esc(p.nama) + '</b><span>Dicocokkan dengan nota</span></span></label></li>';
    });
    return h + '</ul><p class="meta">' + jml + ' dari ' + s.pos.length + ' pos ditandai cocok.</p></section>';
  }

  function lapisAsurans() {
    return '<section class="blok"><h2>Lapis 3: asurans terbatas atas metodologi</h2>' +
      '<p class="isi-teks">Keyakinan independen diberikan atas metodologi platform, yaitu rumus, sumber faktor, dan kontrol datanya, bukan atas angka setiap UMKM. Cara ini menjaga biaya tetap rendah dan mencegah klaim greenwashing. Bagian ini berada di luar aplikasi simulasi.</p></section>';
  }

  J.langkah[5] = {
    n: 5, fase: 'Perhitungan', judul: 'Jaminan data',
    render: function (c) {
      var h = U.kepala(this, 'Jaminan data bertumpu pada tiga lapis: log audit yang tidak bisa diubah diam-diam, verifikasi sampel oleh akuntan pendamping atau koperasi, dan asurans terbatas atas metodologi platform.');
      if (!c.ak.ok) return h + U.terkunci(c, 5);
      return h + lapisLog(c) + hitungUlang(c) + lapisSampel(c) + lapisAsurans();
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
