/*
 * Uji tampilan tanpa browser: tiap langkah hanya fungsi (state) → teks HTML, jadi bisa dijalankan di Node.
 * Dimuat otomatis oleh tests/run.js.
 *
 * Yang dijaga di sini terutama KONTRAK antara HTML dan app.js: setiap data-act, data-ch, data-in, dan
 * data-form yang ditulis di langkah harus punya penangan di app.js. Jika Anda menambah tombol baru tetapi
 * lupa menulis penanganannya, uji di bawah akan gagal dan menyebut namanya.
 */
'use strict';
const path = require('path');
const fs = require('fs');

module.exports = function ({ uji, eq, klon }) {
  const J = globalThis.JEJAK;
  const src = path.join(__dirname, '..', 'src');
  require(path.join(src, 'store.js'));
  require(path.join(src, 'ui.js'));
  fs.readdirSync(path.join(src, 'steps')).filter((f) => /^l\d-/.test(f)).sort().forEach((f) => require(path.join(src, 'steps', f)));
  const S = J.store, U = J.ui, L = J.langkah;
  const N = S.JUMLAH_LANGKAH; // uji ikut berlaku untuk langkah baru yang Anda tambahkan
  const appSrc = fs.readFileSync(path.join(src, 'app.js'), 'utf8');
  const T = '2026-11-26T09:00:00.000Z';

  const uiBaru = () => ({ galat: {}, open: {}, form: { kat: 'bahan', faktorPilih: 'unggas' }, formTangga: { tier: 'T2', latihan: false }, tangga: null, diperiksa: null, rusakPilih: 1, sebelum: {}, konfirmReset: false });
  const awal = () => S.stateAwal(T);
  const semua = () => S.terapkan(awal(), 'izinSemua', {}, T);
  const gambar = (s, n, ui) => { const c = { s, t: S.turunan(s), ui: ui || uiBaru(), ak: S.akses(s, n) }; return L[n].render(c) + U.nav(c, n); };

  /* beberapa keadaan yang mewakili cabang tampilan yang berbeda */
  function keadaan() {
    const dasar = semua();
    const naik = S.terapkan(dasar, 'naikTangga', { id: 'ayam', tier: 'T2', qty: '150', unit: 'kg', fq: '1', sumber: 'Angka latihan, bukan faktor resmi', latihan: true }, T);
    const pos = S.terapkan(naik, 'tambahPos', { nama: 'Minyak goreng', kat: 'bahan', rupiah: '1.200.000', faktorPilih: 'unggas' }, T);
    const bagi = S.terapkan(S.terapkan(pos, 'bagi', { id: 'bank', aktif: true }, T), 'bagi', { id: 'pembeli', aktif: true }, T);
    const rusak = S.terapkan(bagi, 'rusak', { i: 2 }, T);
    const sampel = S.terapkan(dasar, 'sampel', { id: 'ayam', nilai: true }, T);
    const tanpaJual = S.terapkan(dasar, 'izin', { kunci: 'penjualan', nilai: false }, T);
    return { awal: awal(), dasar, naik, pos, bagi, rusak, sampel, tanpaJual };
  }

  console.log('\nTampilan (render)');
  uji('semua langkah terdaftar dengan nomor, fase, dan judul', () => {
    for (let n = 1; n <= N; n++) {
      eq(!!L[n], true, 'langkah ' + n + ' tidak terdaftar'); eq(L[n].n, n); eq(typeof L[n].judul, 'string'); eq(typeof L[n].fase, 'string');
    }
  });
  uji('semua langkah tergambar di semua keadaan tanpa galat dan memuat <h1>', () => {
    const k = keadaan();
    Object.keys(k).forEach((nama) => { for (let n = 1; n <= N; n++) { const h = gambar(k[nama], n); eq(h.indexOf('id="judul-langkah"') >= 0, true, nama + ' langkah ' + n); } });
  });
  uji('langkah yang syaratnya belum terpenuhi menampilkan panel terkunci, yang lain tidak', () => {
    const s = awal();
    eq(S.akses(s, 1).ok, true); eq(S.akses(s, N).ok, N === 1);
    for (let n = 1; n <= N; n++) eq(gambar(s, n).indexOf('<section class="terkunci"') >= 0, !S.akses(s, n).ok, 'langkah ' + n);
  });
  uji('angka kasus awal muncul sama dengan video: 1.163,0 / 863 sampai 1.651 / 46,5 / 13,96', () => {
    const s = semua(), h4 = gambar(s, 4), h6 = gambar(s, 6);
    ['903,3', '129,6', '130,1', '1.163,0', '13,96', '46,5', '70%'].forEach((x) => eq(h4.indexOf(x) >= 0, true, 'langkah 4 tanpa ' + x));
    ['1.163,0', '863', '1.651', '46,5', '13,96', '−11,2%', '+22,3%', '−25,8%', '+41,9%'].forEach((x) => eq(h6.indexOf(x) >= 0, true, 'langkah 6 tanpa ' + x));
  });
  uji('teks dari pengguna di-escape (nama usaha dan nama pos)', () => {
    let s = S.terapkan(semua(), 'usaha', { nilai: '<img src=x onerror=alert(1)>' }, T);
    s = S.terapkan(s, 'tambahPos', { nama: '<b>x</b>', kat: 'bahan', rupiah: '1000', faktorPilih: 'unggas' }, T);
    for (let n = 1; n <= N; n++) { const h = gambar(s, n); eq(h.indexOf('<img src=x') , -1, 'langkah ' + n + ' memuat <img> mentah'); eq(h.indexOf('<b>x</b>'), -1, 'langkah ' + n + ' memuat <b> mentah'); }
  });
  uji('tanpa izin penjualan: intensitas tidak dihitung dan bidang bergantung penjualan tidak bisa dicentang', () => {
    const k = keadaan();
    eq(gambar(k.tanpaJual, 6).indexOf('46,5'), -1);
    eq(gambar(k.tanpaJual, 6).indexOf('izin baca penjualan belum diberikan') >= 0, true);
    eq(gambar(k.tanpaJual, 7).indexOf('data-bidang="penjualan" disabled') >= 0, true);
  });
  uji('pos latihan diberi tanda "latihan" di langkah 4 dan 6 (dan di kartu sumber)', () => {
    const s = keadaan().naik;
    eq(gambar(s, 4).indexOf('class="latihan"') >= 0, true); eq(gambar(s, 6).indexOf('class="latihan"') >= 0, true);
    eq(gambar(s, 4).indexOf('data-act="turunTangga"') >= 0, true);
  });
  uji('langkah 7: paket yang dibagikan hanya berisi bidang terpilih; sebelum dibagikan kosong', () => {
    const k = keadaan();
    eq(gambar(k.dasar, 7).indexOf('<pre class="paket"'), -1);
    const h = gambar(k.bagi, 7);
    eq((h.match(/<pre class="paket"/g) || []).length, 2);
    eq(h.indexOf('penjualan_rp_per_bulan'), -1); eq(h.indexOf('selisih_penjualan_belanja_rp'), -1);
    eq(h.indexOf('total_kgco2e_per_bulan') >= 0, true);
  });
  uji('langkah 5 dan 6 menampilkan rantai putus setelah log dipalsukan', () => {
    const s = keadaan().rusak;
    eq(gambar(s, 5).indexOf('Rantai putus di entri 2') >= 0, true);
    eq(gambar(s, 5).indexOf('data-act="pulihkan"') >= 0, true);
    eq(gambar(s, 6).indexOf('class="cap putus"') >= 0, true);
    eq(gambar(s, 7).indexOf('Rantai log putus') >= 0, true);
  });
  uji('formulir naik tangga muncul hanya untuk pos yang dibuka', () => {
    const s = semua(), ui = uiBaru();
    eq(gambar(s, 4, ui).indexOf('data-form="naikTangga"'), -1);
    ui.tangga = 'ayam';
    eq(gambar(s, 4, ui).indexOf('data-form="naikTangga" data-id="ayam"') >= 0, true);
  });
  uji('id elemen unik dalam satu halaman dan tiap kolom berid punya label', () => {
    const k = keadaan();
    Object.keys(k).forEach((nama) => {
      for (let n = 1; n <= N; n++) {
        const ui = uiBaru(); ui.tangga = 'ayam'; ui.open.tambahPos = true;
        const h = gambar(k[nama], n, ui), ids = (h.match(/ id="([^"]+)"/g) || []).map((x) => x.slice(5, -1));
        const dobel = ids.filter((x, i) => ids.indexOf(x) !== i);
        eq(dobel.length, 0, nama + ' langkah ' + n + ' id ganda: ' + dobel.join(','));
        (h.match(/<input[^>]* id="([^"]+)"[^>]*type="text"|<input[^>]*type="text"[^>]* id="([^"]+)"/g) || []).forEach((tag) => {
          const id = /id="([^"]+)"/.exec(tag)[1];
          eq(h.indexOf('for="' + id + '"') >= 0, true, nama + ' langkah ' + n + ': kolom ' + id + ' tanpa label');
        });
      }
    });
  });

  /* ---- kontrak dengan app.js ---- */
  function blok(awalan, akhir) {
    const i = appSrc.indexOf(awalan); if (i < 0) throw new Error('app.js tidak memuat: ' + awalan);
    const j = appSrc.indexOf(akhir, i); return appSrc.slice(i, j < 0 ? undefined : j);
  }
  const kunciObjek = (teks) => new Set((teks.match(/^ {4}(\w+): /gm) || []).map((x) => x.trim().slice(0, -1)));
  const kasusSwitch = (teks) => new Set((teks.match(/case '(\w+)'/g) || []).map((x) => x.slice(6, -1)));
  const KLIK = kunciObjek(blok('var KLIK = {', '\n  };'));
  const KIRIM = kunciObjek(blok('var KIRIM = {', '\n  };'));
  const PENANGAN = kunciObjek(blok('var PENANGAN = {', '\n  };'));
  const UBAH = kasusSwitch(blok('function saatUbah', '\n  /* ====='));

  function kumpulkan() {
    const hasil = { act: new Set(), ch: new Set(), in_: new Set(), form: new Set() };
    const k = keadaan();
    Object.keys(k).forEach((nama) => {
      for (let n = 1; n <= N; n++) {
        const ui = uiBaru(); ui.tangga = 'ayam'; ui.open.tambahPos = true; ui.form.faktorPilih = 'lain';
        const h = gambar(k[nama], n, ui);
        (h.match(/data-act="(\w+)"/g) || []).forEach((x) => hasil.act.add(x.slice(10, -1)));
        (h.match(/data-ch="(\w+)"/g) || []).forEach((x) => hasil.ch.add(x.slice(9, -1)));
        (h.match(/data-in="(\w+)"/g) || []).forEach((x) => hasil.in_.add(x.slice(9, -1)));
        (h.match(/data-form="(\w+)"/g) || []).forEach((x) => hasil.form.add(x.slice(11, -1)));
      }
    });
    (fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8').match(/data-act="(\w+)"/g) || []).forEach((x) => hasil.act.add(x.slice(10, -1)));
    return hasil;
  }
  const dipakai = kumpulkan();
  const tanpa = (pakai, ada) => [...pakai].filter((x) => !ada.has(x));

  uji('kontrak: setiap data-act di HTML punya penangan KLIK di app.js', () => {
    const hilang = tanpa(dipakai.act, KLIK); eq(hilang.join(', '), '', 'data-act tanpa penangan');
  });
  uji('kontrak: setiap data-ch di HTML punya case di saatUbah (app.js)', () => {
    const hilang = tanpa(dipakai.ch, UBAH); eq(hilang.join(', '), '', 'data-ch tanpa penangan');
  });
  uji('kontrak: setiap data-in di HTML dikenali saatInput (usaha, angka, pos)', () => {
    const hilang = tanpa(dipakai.in_, new Set([...PENANGAN, 'usaha'])); eq(hilang.join(', '), '', 'data-in tanpa penangan');
  });
  uji('kontrak: setiap data-form di HTML punya penangan KIRIM di app.js', () => {
    const hilang = tanpa(dipakai.form, KIRIM); eq(hilang.join(', '), '', 'data-form tanpa penangan');
  });
  uji('kontrak: setiap aksi store yang dipanggil app.js benar-benar ada', () => {
    const dipanggil = new Set((appSrc.match(/S\.act\('(\w+)'/g) || []).map((x) => x.slice(7, -1)));
    const hilang = [...dipanggil].filter((a) => !S.aksi[a]); eq(hilang.join(', '), '', 'aksi tidak ada di store.js');
  });
  uji('index.html memuat semua file src dalam urutan yang benar', () => {
    const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
    const urut = (html.match(/<script src="([^"]+)"/g) || []).map((x) => x.slice(13, -1));
    const harus = ['src/data.js', 'src/calc.js', 'src/hash.js', 'src/store.js', 'src/ui.js'].concat(Array.from({ length: N }, (_, i) => i + 1).map((n) => 'src/steps/' + fs.readdirSync(path.join(src, 'steps')).find((f) => f.indexOf('l' + n + '-') === 0)), ['src/app.js']);
    eq(urut.join(','), harus.join(','));
    harus.forEach((f) => eq(fs.existsSync(path.join(__dirname, '..', f)), true, f));
  });
};
