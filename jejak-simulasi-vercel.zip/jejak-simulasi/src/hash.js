/*
 * hash.js — SHA-256 murni JavaScript + log audit berantai (hash chain).
 *
 * Kenapa tidak memakai crypto.subtle? API itu butuh HTTPS dan bersifat async, sedangkan
 * aplikasi ini harus tetap jalan saat index.html dibuka langsung dari folder (file://).
 * Implementasi di bawah diuji terhadap crypto bawaan Node di tests/run.js.
 *
 * Log audit: tiap entri menyimpan sidik jari (hash) dari isinya + sidik jari entri sebelumnya.
 * Mengubah satu entri membuat rantai putus di entri itu. Ini demonstrasi konsep "log yang tidak
 * bisa diubah diam-diam", bukan pengganti penyimpanan server yang sungguhan.
 */
(function (root) {
  'use strict';
  var J = (root.JEJAK = root.JEJAK || {});

  var K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ]);
  var H0 = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }

  function utf8(teks) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(teks);
    var bin = unescape(encodeURIComponent(teks)), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  /** SHA-256 dari teks UTF-8, hasil heksadesimal 64 karakter. */
  function sha256(teks) {
    var pesan = utf8(String(teks)), n = pesan.length;
    var blok = ((n + 8) >> 6) + 1;
    var buf = new Uint8Array(blok * 64);
    buf.set(pesan);
    buf[n] = 0x80;
    var dv = new DataView(buf.buffer);
    dv.setUint32(buf.length - 8, Math.floor((n * 8) / 4294967296));
    dv.setUint32(buf.length - 4, (n * 8) >>> 0);

    var h = H0.slice(), w = new Uint32Array(64);
    for (var b = 0; b < blok; b++) {
      var t;
      for (t = 0; t < 16; t++) w[t] = dv.getUint32(b * 64 + t * 4);
      for (t = 16; t < 64; t++) {
        var s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
        var s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
        w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
      }
      var a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
      for (t = 0; t < 64; t++) {
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (hh + S1 + ch + K[t] + w[t]) >>> 0;
        var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        var maj = (a & bb) ^ (a & c) ^ (bb & c);
        var t2 = (S0 + maj) >>> 0;
        hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
      }
      h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + bb) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
      h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + g) >>> 0; h[7] = (h[7] + hh) >>> 0;
    }
    return h.map(function (x) { return ('00000000' + x.toString(16)).slice(-8); }).join('');
  }

  /** JSON dengan urutan kunci tetap, supaya sidik jari tidak bergantung urutan penulisan. */
  function kanon(v) {
    if (v === undefined || v === null) return 'null';
    if (typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(kanon).join(',') + ']';
    return '{' + Object.keys(v).sort().map(function (k) { return JSON.stringify(k) + ':' + kanon(v[k]); }).join(',') + '}';
  }

  var GENESIS = new Array(65).join('0');

  function sidikEntri(e) { return sha256([e.prev, e.i, e.t, e.jenis, e.ringkas, kanon(e.data)].join('|')); }

  /** Menambah satu entri di akhir rantai. Tidak mengubah log lama (mengembalikan array baru). */
  function tambah(log, e) {
    var prev = log.length ? log[log.length - 1].hash : GENESIS;
    var baru = { i: log.length + 1, t: e.t, jenis: e.jenis, ringkas: e.ringkas, data: e.data || {}, prev: prev };
    baru.hash = sidikEntri(baru);
    return log.concat([baru]);
  }

  /** Memeriksa seluruh rantai dari awal. di = nomor entri pertama yang bermasalah. */
  function verifikasi(log) {
    var prev = GENESIS;
    for (var k = 0; k < log.length; k++) {
      var e = log[k];
      if (e.prev !== prev) return { ok: false, di: e.i, alasan: 'tautan ke entri sebelumnya tidak cocok', jumlah: log.length };
      if (sidikEntri(e) !== e.hash) return { ok: false, di: e.i, alasan: 'isi entri tidak cocok dengan sidik jarinya', jumlah: log.length };
      prev = e.hash;
    }
    return { ok: true, di: null, alasan: '', jumlah: log.length, kepala: prev };
  }

  /** Segel kartu: sidik jari isi kartu + kepala log. Berubah jika angka atau log berubah. */
  function segel(isi, kepalaLog) { return sha256(kanon(isi) + '|' + kepalaLog); }

  /** "3f9ac20b…" → "3F9A-C20B" */
  function segelPendek(hex) { return (hex.slice(0, 4) + '-' + hex.slice(4, 8)).toUpperCase(); }

  J.hash = { sha256: sha256, kanon: kanon, GENESIS: GENESIS, tambah: tambah, verifikasi: verifikasi, segel: segel, segelPendek: segelPendek };
  if (typeof module !== 'undefined' && module.exports) module.exports = J.hash;
})(typeof window !== 'undefined' ? window : globalThis);
