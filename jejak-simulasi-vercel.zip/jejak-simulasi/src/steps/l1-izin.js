/*
 * Langkah 1: Persetujuan.
 * Cara menambah langkah baru: salin file ini, ganti nomor, daftarkan di index.html,
 * dan tambahkan syaratnya di SYARAT (store.js) dan JUMLAH_LANGKAH.
 * Setiap langkah punya: n, fase, judul, dan render(c) yang mengembalikan teks HTML.
 *   c.s = state, c.t = hasil hitung (store.turunan), c.ui = state tampilan sementara, c.ak = akses langkah ini.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui;

  J.langkah[1] = {
    n: 1, fase: 'Penerapan', judul: 'Persetujuan',
    render: function (c) {
      var s = c.s;
      var jumlah = D.izin.filter(function (i) { return s.izin[i.id]; }).length, semua = jumlah === D.izin.length;
      var h = U.kepala(this, 'Tanpa persetujuan, tidak ada data yang boleh mengalir. Pemilik usaha memegang semua tombolnya, dan setiap izin bisa dicabut lagi kapan saja.');

      h += '<section class="blok"><h2>Kasus yang disimulasikan</h2>' +
        '<p class="isi-teks">Warung makan hipotetis dengan penjualan ' + C.fmtJuta(D.kasus.penjualan) + ' per bulan, sekitar 70% lewat QRIS. ' +
        'Standar keberlanjutan mulai berlaku, sehingga pembeli korporat dan bank membutuhkan data emisi dari pemasok mereka, termasuk dari usaha sekecil ini.</p>' +
        '<div class="isi lebar"><label for="f-usaha">Nama usaha di simulasi</label><span class="kolom">' +
        '<input id="f-usaha" type="text" maxlength="40" autocomplete="off" data-key="usaha" data-in="usaha" data-ch="usaha" value="' + U.esc(s.usaha) + '"></span></div></section>';

      h += '<section class="blok"><h2>Izin dari pemilik usaha</h2><ul class="daftar-izin">';
      D.izin.forEach(function (i) {
        var on = !!s.izin[i.id];
        h += '<li class="izin' + (on ? ' aktif' : '') + '">' +
          '<label class="sakelar"><input type="checkbox" role="switch" data-ch="izin" data-kunci="' + i.id + '"' + (on ? ' checked' : '') + '>' +
          '<span class="geser" aria-hidden="true"></span><span class="teks"><b>' + i.judul + '</b><span>' + i.isi + '</span></span></label>' +
          '<p class="meta"><span class="status">' + (on ? U.ikon('cek', 15) + 'Diberikan' : 'Belum diberikan') + '</span>' +
          'Dipakai di ' + i.dipakai.charAt(0).toLowerCase() + i.dipakai.slice(1) + '.</p></li>';
      });
      h += '</ul><div class="aksi-baris">';
      if (semua) h += '<p class="catatan ok">' + U.ikon('cek') + '<span>Semua izin diberikan. Coba matikan salah satu: langkah yang bergantung padanya langsung terkunci.</span></p>';
      else h += '<button type="button" class="tombol utama" data-act="izinSemua">Izinkan semua untuk simulasi</button><span class="petunjuk">atau nyalakan satu per satu</span>';
      h += '</div></section>';

      h += '<section class="blok"><h2>Hak pemilik usaha</h2><ul class="hak">' +
        '<li><b>Data tetap milik UMKM.</b> Platform hanya membaca atas persetujuan eksplisit, dengan tujuan terbatas.</li>' +
        '<li><b>Hak cabut.</b> Mematikan izin menghentikan aliran data dan akses pihak lain.</li>' +
        '<li><b>Hak membagikan selektif.</b> Bank dan pembeli hanya menerima bidang yang dipilih pemilik.</li></ul>' +
        '<p class="sumber">Dasar: UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi.</p></section>';
      return h;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
