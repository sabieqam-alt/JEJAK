/*
 * Langkah 4: Estimasi emisi dan label T1/T2/T3 (perhitungan yang terlihat langkah demi langkah)
 * termasuk "putaran perbaikan": naik tangga dari T1 ke T2 atau T3.
 */
(function (root) {
  'use strict';
  var J = root.JEJAK, D = J.data, C = J.calc, U = J.ui, S = J.store;
  var F = C.fmtNum, G = C.fmtRingkas, R = C.fmtRp, KG = U.KG;

  /** Dua baris langkah hitung dengan angka yang sebenarnya dipakai. */
  function rumus(r) {
    if (r.metode === 'kwh') return [
      R(r.rupiah) + ' ÷ Rp' + G(r.tarif, 2) + ' per kWh = <b>' + F(r.kwh, 1) + ' kWh</b>',
      F(r.kwh, 1) + ' kWh × ' + G(r.faktor, 4) + ' kgCO<sub>2</sub>/kWh = <b>' + F(r.kg, 1) + ' ' + KG + '</b>'];
    if (r.metode === 'usd') return [
      R(r.rupiah) + ' ÷ Rp' + G(r.kurs, 2) + ' per USD = <b>USD' + F(r.usd, 1) + '</b>',
      'USD' + F(r.usd, 1) + ' × ' + G(r.faktor, 4) + ' ' + KG + '/USD = <b>' + F(r.kg, 1) + ' ' + KG + '</b>'];
    var u = U.esc(r.unit);
    return [G(r.qty, 2) + ' ' + u + ' × ' + G(r.faktor, 4) + ' ' + KG + '/' + u + ' = <b>' + F(r.kg, 1) + ' ' + KG + '</b>'];
  }

  function tabel(c) {
    var hh = c.t.h, s = c.s;
    var h = '<div class="gulir"><table class="buku hitung"><thead><tr><th scope="col">Pos</th><th scope="col" class="angka">Belanja</th>' +
      '<th scope="col" class="angka">' + KG + ' per bulan</th><th scope="col" class="angka sekunder">Porsi</th><th scope="col">Label</th></tr></thead>';
    hh.rows.forEach(function (r) {
      var p = S.cariPos(s, r.id);
      h += '<tbody class="pos-hitung"><tr class="utama"><th scope="row"><span class="warna" style="--w:' + U.warna(r.slot) + '" aria-hidden="true"></span>' + U.esc(r.nama) + '<small>' + p.cakupan + '</small></th>' +
        '<td class="angka" data-l="Belanja">' + R(r.rupiah) + '</td><td class="angka" data-l="kgCO2e per bulan"><b>' + F(r.kg, 1) + '</b></td><td class="angka sekunder" data-l="Porsi">' + C.fmtPct(r.porsi) + '</td>' +
        '<td data-l="Label">' + U.tingkat(r.tier, p.latihan) + '</td></tr>' +
        '<tr class="langkah"><td colspan="5">' + rumus(r).map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</td></tr></tbody>';
    });
    h += '<tfoot><tr class="total"><th scope="row">Total terekam digital</th><td class="angka" data-l="Belanja">' + R(hh.terekam) + '</td><td class="angka" data-l="kgCO2e per bulan">' + F(hh.totalKg, 1) + '</td><td class="angka sekunder" data-l="Porsi">100%</td><td></td></tr></tfoot></table></div>';
    return h;
  }

  function ringkasan(c) {
    var hh = c.t.h, s = c.s, dasar = S.dasar();
    var h = '<dl class="statistik">' +
      '<div><dt>Setahun (× 12)</dt><dd><span class="n angka">' + F(hh.tahunTon, 2) + '</span> t' + U.CO2E + '</dd></div>' +
      '<div><dt>Intensitas</dt><dd>' + (hh.intensitas == null ? '<span class="n angka">–</span> <span class="kecil">butuh izin penjualan</span>' : '<span class="n angka">' + F(hh.intensitas, 1) + '</span> ' + KG + ' per Rp1 juta penjualan') + '</dd></div>' +
      '<div><dt>Cakupan data</dt><dd><span class="n angka">' + C.fmtPct(hh.cakupan, 0) + '</span> belanja terekam digital</dd></div></dl>';
    h += '<div class="tumpuk" role="img" aria-label="Porsi emisi: ' + hh.rows.map(function (r) { return U.esc(r.nama) + ' ' + C.fmtPct(r.porsi); }).join(', ') + '">' +
      hh.rows.map(function (r) {
        return '<span style="--w:' + U.warna(r.slot) + ';flex:' + Math.max(r.kg, 0.0001) + ' 1 0" title="' + U.esc(r.nama) + ': ' + F(r.kg, 1) + ' kgCO2e (' + C.fmtPct(r.porsi) + ')"></span>';
      }).join('') + '</div>' +
      '<ul class="legenda">' + hh.rows.map(function (r) {
        return '<li><i style="--w:' + U.warna(r.slot) + '"></i>' + U.esc(r.nama) + ' <b class="angka">' + C.fmtPct(r.porsi) + '</b></li>';
      }).join('') + '</ul>';
    var d = hh.totalKg - dasar.totalKg;
    if (Math.abs(d) >= 0.05) h += '<p class="selisih">Dibanding kasus awal (' + F(dasar.totalKg, 1) + '): <b>' + (d > 0 ? '+' : '') + F(d, 1) + ' ' + KG + ' (' + C.fmtTanda(d / dasar.totalKg) + ')</b>.</p>';
    return h;
  }

  function parameter(c) {
    var s = c.s, ui = c.ui;
    var h = '<section class="blok"><h2>Parameter dan sumbernya</h2><div class="kisi-param">';
    [['kurs', 'Rp', 'per USD'], ['tarif', 'Rp', 'per kWh'], ['jaringan', '', 'kgCO<sub>2</sub> per kWh']].forEach(function (x) {
      var k = x[0], info = D.paramInfo[k];
      h += U.inputAngka({ kunci: 'angka:' + k, masuk: 'angka', nilai: G(s.param[k], 4), label: info.label, awalan: x[1], akhiran: x[2], data: { kunci: k }, galat: ui.galat['angka:' + k], bantu: 'Sumber: ' + info.sumber });
    });
    h += '</div>';
    var t1 = s.pos.filter(function (p) { return p.kat === 'bahan' && p.tier === 'T1'; });
    if (t1.length) {
      h += '<details class="rinci" data-key="faktorPos"' + (ui.open.faktorPos ? ' open' : '') + '><summary>Faktor emisi per pos (T1)</summary><div class="kisi-param">';
      t1.forEach(function (p) {
        var kunci = 'pos:' + p.id + ':faktorUSD';
        h += U.inputAngka({ kunci: kunci, masuk: 'pos', nilai: G(p.faktorUSD, 4), label: U.esc(p.nama), akhiran: 'kgCO<sub>2</sub>e per USD', data: { id: p.id, bidang: 'faktorUSD' }, galat: ui.galat[kunci], bantu: 'Sumber: ' + U.esc(p.sumberFaktor) });
      });
      h += '</div></details>';
    }
    h += '<p class="catatan awas">' + U.ikon('awas') + '<span>' + D.catatanJujur + '</span></p>';
    return h + '</section>';
  }

  function formNaik(c, p) {
    var f = c.ui.formTangga;
    return '<form class="form-tangga" data-form="naikTangga" data-id="' + U.esc(p.id) + '" novalidate>' +
      '<fieldset class="pilih"><legend>Naik ke tingkat</legend>' +
      '<label><input type="radio" name="tier" value="T2" data-ch="formTangga" data-nama="tier"' + (f.tier === 'T2' ? ' checked' : '') + '> T2: kuantitas fisik × faktor per satuan</label>' +
      '<label><input type="radio" name="tier" value="T3" data-ch="formTangga" data-nama="tier"' + (f.tier === 'T3' ? ' checked' : '') + '> T3: faktor khusus dari pemasok</label></fieldset>' +
      '<div class="kisi-param">' +
      '<div class="isi"><label for="nt-qty">Kuantitas per bulan</label><span class="kolom"><input id="nt-qty" class="angka" name="qty" type="text" inputmode="decimal" autocomplete="off"><input class="satuan" name="unit" type="text" maxlength="12" placeholder="kg" aria-label="Satuan kuantitas" autocomplete="off"></span><span class="bantu">Misalnya kilogram dari nota pembelian.</span></div>' +
      '<div class="isi"><label for="nt-fq">' + (f.tier === 'T3' ? 'Faktor dari pemasok' : 'Faktor per satuan') + '</label><span class="kolom"><input id="nt-fq" class="angka" name="fq" type="text" inputmode="decimal" autocomplete="off"><span class="ak">' + KG + ' per satuan</span></span></div>' +
      '<div class="isi lebar"><label for="nt-sumber">Sumber faktor</label><span class="kolom"><input id="nt-sumber" name="sumber" type="text" maxlength="120" autocomplete="off"></span><span class="bantu">Wajib diisi. Aplikasi tidak menyediakan faktor T2 atau T3 supaya tidak ada angka tanpa sumber.</span></div></div>' +
      '<div class="aksi-baris"><button type="submit" class="tombol utama">Hitung ulang di tingkat ini</button>' +
      '<button type="button" class="tombol sekunder" data-act="isiLatihan">Isi angka latihan</button>' +
      '<button type="button" class="tombol teks" data-act="tutupTangga">Batal</button>' +
      (c.ui.galat.naikTangga ? '<span class="galat" role="alert">' + U.esc(c.ui.galat.naikTangga) + '</span>' : '') + '</div>' +
      '<p class="bantu">Angka latihan sengaja bulat (' + C.fmtRingkas(D.latihan.qty, 0) + ' ' + D.latihan.unit + ' × ' + C.fmtRingkas(D.latihan.fq, 0) + ') dan diberi tanda "latihan" di mana pun muncul. Itu bukan faktor resmi.</p></form>';
  }

  function tangga(c) {
    var s = c.s, ui = c.ui, b = s.band;
    var tiers = [
      { t: 'T1', lo: b.c3[0], hi: b.c3[1], ket: 'rentang dari esai' },
      { t: 'T2', lo: b.t2[0], hi: b.t2[1], ket: 'ilustrasi' },
      { t: 'T3', lo: b.t3[0], hi: b.t3[1], ket: 'ilustrasi' }
    ];
    var skala = Math.log(b.c3[1]) - Math.log(b.c3[0]);
    var h = '<section class="blok"><h2>Tangga kualitas data dan putaran perbaikan</h2>' +
      '<p class="isi-teks">Makin spesifik datanya, makin sempit rentang ketidakpastiannya. Pemilik usaha naik tangga dengan mencatat lebih rinci, misalnya kilogram pembelian dari nota. Estimasi lalu dihitung ulang pada tingkat yang lebih tinggi. Batang di bawah tiap tingkat menunjukkan lebar rentang faktornya: makin pendek, makin pasti.</p><ol class="tangga">';
    tiers.forEach(function (x) {
      var info = D.tingkat[x.t];
      var lebar = Math.max(3, Math.min(100, (Math.log(x.hi) - Math.log(x.lo)) / skala * 100));
      var isi = s.pos.filter(function (p) { return p.tier === x.t; }).map(function (p) { return U.esc(p.nama); }).join(', ');
      h += '<li class="rung ' + x.t.toLowerCase() + '"><div class="rung-kepala">' + U.tingkat(x.t) + '<b>' + info.judul + '</b><span class="mutu">' + info.mutu + '</span></div>' +
        '<div class="rentang-bar" aria-hidden="true"><span style="width:' + lebar.toFixed(1) + '%"></span></div>' +
        '<p class="meta">Faktor ×' + G(x.lo, 2) + ' sampai ×' + G(x.hi, 2) + ' (' + x.ket + '). ' + (isi ? 'Pos di tingkat ini: ' + isi + '.' : 'Belum ada pos di tingkat ini.') + '</p></li>';
    });
    h += '</ol>';
    s.pos.filter(function (p) { return p.kat === 'bahan'; }).forEach(function (p) {
      var buka = ui.tangga === p.id;
      if (p.tier === 'T1') {
        h += '<div class="naik"><div class="naik-baris"><span><b>' + U.esc(p.nama) + '</b> masih T1, dihitung dari belanja.</span>' +
          (buka ? '' : '<button type="button" class="tombol sekunder" data-act="bukaTangga" data-id="' + U.esc(p.id) + '">Naik tangga</button>') + '</div>' + (buka ? formNaik(c, p) : '') + '</div>';
      } else {
        h += '<div class="naik selesai"><div class="naik-baris"><span><b>' + U.esc(p.nama) + '</b> sudah ' + U.tingkat(p.tier, p.latihan) + ': ' + C.fmtRingkas(p.qty, 2) + ' ' + U.esc(p.unit) + ' × ' + C.fmtRingkas(p.fq, 4) + ' ' + KG + '/' + U.esc(p.unit) + '. Sumber: ' + U.esc(p.sumberFq) + '.</span>' +
          '<button type="button" class="tombol teks" data-act="turunTangga" data-id="' + U.esc(p.id) + '">Kembalikan ke T1</button></div></div>';
      }
    });
    var lis = S.cariPos(s, 'listrik');
    if (lis) h += '<p class="meta">Listrik sudah T2 karena dihitung dari kWh, bukan dari belanja.</p>';
    return h + '</section>';
  }

  function skenario(c) {
    var lis = S.cariPos(c.s, 'listrik');
    if (!lis) return '';
    var naik = lis.rupiah === D.skenarioListrik, awal = D.pos.filter(function (x) { return x.id === 'listrik'; })[0].rupiah;
    return '<section class="blok"><h2>Coba skenario</h2><p class="isi-teks">Latihan dari Modul 4: bagaimana jika belanja token listrik naik menjadi ' + C.fmtJuta(D.skenarioListrik) + ' per bulan? Perhatikan porsi listrik dan totalnya.</p>' +
      '<div class="aksi-baris"><button type="button" class="tombol sekunder" data-act="latihanListrik">' + (naik ? 'Kembalikan token listrik ke ' + C.fmtJuta(awal) : 'Naikkan token listrik menjadi ' + C.fmtJuta(D.skenarioListrik)) + '</button></div></section>';
  }

  J.langkah[4] = {
    n: 4, fase: 'Perhitungan', judul: 'Estimasi dan label',
    render: function (c) {
      var h = U.kepala(this, 'Setiap baris dihitung dengan metode yang cocok dengan datanya, lalu diberi label T1, T2, atau T3. Mulai dari T1 supaya cepat ada angka, lalu naik tangga.');
      if (!c.ak.ok) return h + U.terkunci(c, 4);
      h += '<section class="blok"><h2>Perhitungan per pos</h2>' + tabel(c) + ringkasan(c) + '</section>';
      h += parameter(c) + tangga(c) + skenario(c);
      return h;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
